// Arayüz: listeleme, filtreleme, sıralama, dışa aktarma (mevcut davranış korunur).

const $ = (id) => document.getElementById(id);

function renderStats() {
  const vals = catalog.map((x) => get(x.id));
  $('total').textContent = catalog.length;
  $('watched').textContent = vals.filter((x) => x.watched).length;
  $('favcount').textContent = vals.filter((x) => x.favorite).length;
  $('rated').textContent = vals.filter((x) => x.rating !== null && x.rating !== undefined && x.rating !== '').length;
}

// Seçili ana türler (çoklu seçim panelinden).
function seciliTurler() {
  return Array.from(document.querySelectorAll('#turPanel input[type="checkbox"]:checked')).map((c) => c.value);
}

// Seçili etiketler (çoklu seçim panelinden).
function seciliEtiketler() {
  return Array.from(document.querySelectorAll('#etPanel input[type="checkbox"]:checked')).map((c) => c.value);
}

// Özellik filtreleri: alan → seçili değerler (çiplerden).
function seciliOzellikler() {
  const m = {};
  document.querySelectorAll('#filtreEk .cip[aria-pressed="true"]').forEach((b) => {
    (m[b.dataset.alan] = m[b.dataset.alan] || []).push(b.dataset.deger);
  });
  return m;
}

// "Sınıflandırılmamış" filtresi etkin mi?
function sinifsizAktif() {
  const el = $('sinifsiz');
  return !!(el && el.checked);
}

// Arama havuzu: başlık + eski genre + yeni taksonomi alanları.
function aramaHavuzu(x) {
  return [x.title, x.genre, ...(x.turler || []), ...(x.altTurler || []), ...(x.etiketler || [])]
    .join(' ')
    .toLocaleLowerCase('tr');
}

// Bir özellik grubunu değerlendirir. Seçim yoksa geçer (true).
// ortam: alanı olmayan kayıtlar "Canlı aksiyon" DEĞİL, ORTAM_BELIRTILMEMIS sayılır.
function ozellikGecti(x, alan, secili) {
  if (!secili.length) return true;
  if (alan === 'ortam') {
    const deger = x.ortam || ORTAM_BELIRTILMEMIS;
    return secili.includes(deger);
  }
  return secili.includes(x[alan]);
}

function filtered() {
  const secili = seciliTurler();
  const sinifsiz = sinifsizAktif();
  const etiketler = seciliEtiketler();
  const ozellik = seciliOzellikler();
  let arr = catalog.filter((x) => {
    const s = get(x.id);
    const q = $('q').value.toLocaleLowerCase('tr');
    // Tür grubu: grup içinde OR. Seçili türlerden biri VEYA sınıflandırılmamış.
    const turOk = (!secili.length && !sinifsiz)
      || secili.some((t) => (x.turler || []).includes(t))
      || (sinifsiz && !(x.turler || []).length);
    // Etiket grubu: grup içinde OR.
    const etOk = !etiketler.length || etiketler.some((e) => (x.etiketler || []).includes(e));
    // Özellik grupları: her grup kendi içinde OR; gruplar arası AND.
    const ozOk = Object.entries(ozellik).every(([alan, seciliDeger]) => ozellikGecti(x, alan, seciliDeger));
    return (
      (!$('kind').value || x.kind === $('kind').value) &&
      turOk &&
      etOk &&
      ozOk &&
      (!q || aramaHavuzu(x).includes(q)) &&
      (!$('status').value || ({ watched: !!s.watched, unwatched: !s.watched, fav: !!s.favorite, rated: !!s.rating, unrated: !s.rating })[$('status').value])
    );
  });
  const sort = $('sort').value;
  arr.sort((a, b) => {
    const sa = get(a.id), sb = get(b.id);
    if (sort === 'rating') return (sb.rating || 0) - (sa.rating || 0) || a.title.localeCompare(b.title);
    if (sort === 'ratingLow') return (sa.rating || 99) - (sb.rating || 99) || a.title.localeCompare(b.title);
    if (sort === 'personal') return (sa.rank || 99999) - (sb.rank || 99999) || a.title.localeCompare(b.title);
    if (sort === 'genre') return a.genre.localeCompare(b.genre) || a.title.localeCompare(b.title);
    return sort === 'za' ? b.title.localeCompare(a.title) : a.title.localeCompare(b.title);
  });
  return arr;
}

// Aktif filtre özetini gösterir (kullanıcı hangi filtrelerin açık olduğunu görsün).
function renderAktifFiltre() {
  const el = $('aktifFiltre');
  if (!el) return;
  const parcalar = [];
  const kind = $('kind').value;
  if (kind) parcalar.push(kind);
  const t = seciliTurler();
  if (t.length) parcalar.push('Tür: ' + t.join(', '));
  if (sinifsizAktif()) parcalar.push('Sınıflandırılmamış');
  const e = seciliEtiketler();
  if (e.length) parcalar.push('Etiket: ' + e.join(', '));
  const oz = seciliOzellikler();
  Object.entries(oz).forEach(([alan, degerler]) => {
    const ad = { ortam: 'Ortam', bicim: 'Biçim', animasyonGelenegi: 'Animasyon geleneği' }[alan] || alan;
    parcalar.push(ad + ': ' + degerler.join(', '));
  });
  const st = $('status').value;
  if (st) parcalar.push('Durum: ' + $('status').selectedOptions[0].textContent);
  const q = $('q').value;
  if (q) parcalar.push('Arama: "' + q + '"');
  el.textContent = parcalar.length ? 'Aktif filtreler → ' + parcalar.join(' · ') : '';
}

function render() {
  const arr = filtered();
  $('resultcount').textContent = arr.length + ' yapım listeleniyor';
  renderAktifFiltre();
  $('list').innerHTML = '';
  if (!arr.length) {
    $('list').innerHTML = '<div class="empty">Bu filtrelerle eşleşen yapım yok.</div>';
    return;
  }
  arr.forEach((x) => {
    const s = get(x.id);
    const el = document.createElement('article');
    el.className = 'item';
    el.innerHTML = `<div class="top"><div><div class="title"></div><span class="tag"></span></div><button class="fav" title="Favoriye ekle">${s.favorite ? '★' : '☆'}</button></div>
 <div class="actions"><label>İzleme durumu<select class="watched"><option value="0">İzleyeceğim</option><option value="1">İzledim</option></select></label><label>Puan<select class="rating"><option value="">Puan yok</option>${Array.from({ length: 10 }, (_, i) => `<option value="${i + 1}">${i + 1}/10</option>`).join('')}</select></label><label>Özel sıram<input class="rank" type="number" min="1" placeholder="Örn. 1"></label></div>`;
    el.querySelector('.title').textContent = x.title;
    const etiket = (x.turler && x.turler.length)
      ? x.kind + ' · ' + x.turler.slice(0, 3).join(', ') + (x.turler.length > 3 ? '…' : '')
      : x.kind + ' · sınıflandırılmamış';
    el.querySelector('.tag').textContent = etiket;
    el.querySelector('.fav').onclick = () => update(x.id, 'favorite', !s.favorite);
    el.querySelector('.watched').value = s.watched ? '1' : '0';
    el.querySelector('.watched').onchange = (e) => update(x.id, 'watched', e.target.value === '1');
    el.querySelector('.rating').value = s.rating || '';
    el.querySelector('.rating').onchange = (e) => update(x.id, 'rating', e.target.value ? Number(e.target.value) : null);
    el.querySelector('.rank').value = s.rank || '';
    el.querySelector('.rank').onchange = (e) => update(x.id, 'rank', e.target.value ? Number(e.target.value) : null);
    $('list').append(el);
  });
}

function download(name, content, type) {
  const blob = new Blob([content], { type });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
}

function rows() {
  return catalog.map((x) => ({ ...x, ...get(x.id), favorite: !!get(x.id).favorite, watched: !!get(x.id).watched }));
}

function disaAktarJSON() {
  // v2: kullanıcı düzeltmeleri (ayrı anahtar) da yedeğe dahil edilir.
  // v1 yedekleri geriye dönük uyumlu kalır (bkz. iceaktarma.js).
  download('film-dizi-arsiv-yedegi.json', JSON.stringify({ version: 2, exportedAt: new Date().toISOString(), catalog, ratingsAndPreferences: state, uygunluk: getUygunlukRaw() }, null, 2), 'application/json');
}

function disaAktarCSV() {
  const cols = ['title', 'kind', 'genre', 'watched', 'favorite', 'rating', 'rank'];
  const yeniCols = ['turler', 'altTurler', 'etiketler', 'bicim', 'ortam', 'animasyonGelenegi', 'gozdenGecir'];
  const esc = (v) => '"' + String(v ?? '').replaceAll('"', '""') + '"';
  // Çoklu değerler tek hücrede "|" ile birleştirilir (CSV ayracı ";" ile çakışmaz).
  const coklu = (v) => (Array.isArray(v) ? v.join('|') : '');
  const satir = (x) =>
    [...cols, ...yeniCols]
      .map((k) => {
        if (k === 'turler' || k === 'altTurler' || k === 'etiketler') return esc(coklu(x[k]));
        if (k === 'gozdenGecir') return esc(x.gozdenGecir === true ? 'evet' : 'hayır');
        return esc(x[k]);
      })
      .join(';');
  const csv = '\uFEFF' + [[...cols, ...yeniCols].map(esc).join(';'), ...rows().map(satir)].join('\r\n');
  download('film-dizi-arsivim.csv', csv, 'text/csv;charset=utf-8');
}

// Başlatma ve içe aktarma akışı (doğrulama → önizleme → onay → yedek → uygula → rapor).

let bekleyenAnaliz = null; // önizlemesi gösterilen analiz

function modalGizle(id) {
  $(id).classList.add('hidden');
}
function modalGoster(id) {
  $(id).classList.remove('hidden');
}

function kacisla(s) {
  const d = document.createElement('div');
  d.textContent = s == null ? '' : String(s);
  return d.innerHTML;
}

function onizlemeGoster(analiz) {
  const ozet = [
    '<div class="satir"><b>Yedek sürümü:</b> ' + kacisla(analiz.version) + '</div>',
    analiz.exportedAt ? '<div class="satir"><b>Dışa aktarma tarihi:</b> ' + kacisla(analiz.exportedAt) + '</div>' : '',
    '<div class="satir"><b>Dosyadaki kayıt:</b> ' + analiz.fileTotal + '</div>',
    '<div class="satir"><b>Şu anki kayıt:</b> ' + analiz.currentCount + '</div>',
    '<div class="satir"><b>Aktarılabilir geçerli kayıt:</b> ' + Object.keys(analiz.valid).length + '</div>',
    '<div class="satir"><b>Yeni kayıt (sizde yok):</b> ' + analiz.newIds.length + '</div>',
    '<div class="satir"><b>Çakışan kayıt (ikisinde de var):</b> ' + analiz.conflicts.length + '</div>',
    '<div class="satir"><b>Bilinmeyen ID (katalogda yok):</b> ' + analiz.unknownIds.length + '</div>',
    '<div class="satir"><b>Geçersiz değer:</b> ' + analiz.invalidValues.length + '</div>',
    analiz.uygunlukVar
      ? '<div class="satir"><b>Uygunluk düzeltmesi (yedekte):</b> ' + analiz.uygunlukSayisi + ' kayıt aktarılacak</div>'
      : '<div class="satir"><b>Uygunluk düzeltmesi:</b> yedekte yok → mevcut düzeltmeleriniz korunacak</div>',
  ].join('');
  $('iceOzet').innerHTML = ozet;

  let detay = '';
  if (analiz.unknownIds.length) {
    detay += '<div class="blok"><b>Bilinmeyen ID\'ler (atlanacak):</b><div class="liste">' + analiz.unknownIds.map(kacisla).join(', ') + '</div></div>';
  }
  if (analiz.invalidValues.length) {
    detay += '<div class="blok"><b>Geçersiz değerler (atlanacak):</b><div class="liste">' +
      analiz.invalidValues.map((g) => kacisla(g.id + ' → ' + g.field + ' = ' + JSON.stringify(g.value))).join('<br>') + '</div></div>';
  }
  if (analiz.conflicts.length) {
    detay += '<div class="blok"><b>Çakışmalar (mevcut → dosya):</b><div class="liste">' +
      analiz.conflicts.map((c) => kacisla(c.id + ': ' + JSON.stringify(c.current) + ' → ' + JSON.stringify(c.file))).join('<br>') + '</div></div>';
  }
  if (!detay) detay = '<div class="blok muted">Atlanacak veya çakışan kayıt yok.</div>';
  $('iceDetay').innerHTML = detay;

  modalGoster('iceModal');
}

function iceAktarmaDosyaSecildi(file) {
  const reader = new FileReader();
  reader.onload = () => {
    let obj;
    try {
      obj = JSON.parse(reader.result);
    } catch (e) {
      alert('Yedek dosyası okunamadı: geçerli bir JSON değil. Hiçbir veri değiştirilmedi.');
      return;
    }
    const analiz = analizEt(obj, catalog, state);
    if (!analiz.ok) {
      alert('Yedek reddedildi: ' + analiz.error + '\nHiçbir veri değiştirilmedi.');
      return;
    }
    bekleyenAnaliz = analiz;
    onizlemeGoster(analiz);
  };
  reader.onerror = () => alert('Dosya okunamadı. Hiçbir veri değiştirilmedi.');
  reader.readAsText(file);
}

function iceAktarmaUygula(mode) {
  if (!bekleyenAnaliz) return;
  // Kurtarma başarısızsa (tutarsız veri) içe aktarma da engellenir.
  if (veriKilitliMi()) {
    modalGizle('iceModal');
    alert('Veri güvenlik kilidi etkin: önceki içe aktarma kurtarılamadı. Yeni içe aktarma yapılamaz. Lütfen sayfayı yenileyin veya yedeği geri alın.');
    return;
  }
  const analiz = bekleyenAnaliz;
  const yeniDurum = hesaplaYeniDurum(mode, analiz, state);
  const yeniUygunluk = hesaplaYeniUygunlukDurum(mode, analiz, getUygunlukRaw());

  // Atomik yazma: önce yedek (hem kullanıcı verisi hem uygunluk), sonra journal ile yaz.
  if (!backupNow()) {
    alert('Otomatik yedek alınamadı. Güvenlik için içe aktarma durduruldu. Hiçbir veri değiştirilmedi.');
    return;
  }
  uygunlukBackupAl();
  const eskiJSON = JSON.stringify(state);
  const sonuc = ikiAnahtarYaz(yeniDurum, yeniUygunluk);
  if (!sonuc.ok) {
    alert('İçe aktarma uygulanamadı.\n\n' + sonuc.hata + '\n\nMevcut veriniz korunuyor. "Son işlemi geri al" düğmesini de kullanabilirsiniz.');
    return;
  }

  state = yeniDurum;
  setUygunlukState(yeniUygunluk);
  const rapor = raporOlustur(mode, analiz, JSON.parse(eskiJSON), yeniDurum);
  renderStats();
  render();
  modalGizle('iceModal');
  bekleyenAnaliz = null;

  const modAd = mode === 'birlestir' ? 'Birleştir' : 'Değiştir';
  const uySatir = analiz.uygunlukVar
    ? 'Uygunluk düzeltmesi aktarılan: ' + rapor.uygunlukAktarilan + '\n'
    : 'Uygunluk düzeltmesi: yedekte yok → mevcut düzeltmeleriniz KORUNDU.\n';
  alert(
    'İçe aktarma tamamlandı (' + modAd + ').\n\n' +
    'Aktarılan kayıt: ' + rapor.aktarilan + '\n' +
    'Korunan mevcut kayıt: ' + rapor.korunan + '\n' +
    'Atlanan kayıt: ' + rapor.atilan +
    ' (bilinmeyen ID: ' + rapor.bilinmeyenId + ', geçersiz değer: ' + rapor.gecersizDeger + ')\n' +
    'Yeni kayıt: ' + rapor.yeniKayit + '\n' +
    'Çakışan kayıt: ' + rapor.cakisanKayit + '\n' +
    'Toplam kullanıcı kaydı (şimdi): ' + rapor.sonucKayitSayisi + '\n' +
    uySatir + '\n' +
    'Gerekirse "Son işlemi geri al" düğmesiyle önceki duruma dönebilirsiniz.'
  );
}

function baslat() {
  // Yarım kalmış içe aktarma işlemi varsa önce kurtar (journal tabanlı atomiklik).
  const kurtarma = journalKurtar();
  if (kurtarma) {
    if (kurtarma.kurtarildi === 'basarisiz') {
      // Tutarsız veri: veri değiştiren işlemleri kilitle ve açıkça bildir.
      setVeriKilitli(true);
      alert('DİKKAT: Önceki işlem kurtarılamadı. Tutarsız veri olabilir.\n' + kurtarma.detay +
        '\n\nVeri kaybını önlemek için yeni değişiklik yapılması engellendi.\nLütfen sayfayı yenileyin; sorun sürerse yedeği geri alın.');
    } else {
      alert('İşlem kurtarma: ' + kurtarma.detay);
    }
  }

  const sonuc = loadState();

  // Migration/şema durumunu bilgilendir (hata varsa veri değişmedi).
  if (sonuc && sonuc.ok === false) {
    alert('Veri yükleme uyarısı: ' + sonuc.error);
  } else if (sonuc && sonuc.durum === 'migrate-edildi') {
    alert(
      'Veri şeması güncellendi (v' + sonuc.fromVersion + ' → v' + sonuc.toVersion + ').\n' +
      'Taşınan kayıt: ' + sonuc.rapor.toplamKayit + '\n' +
      'Migration öncesi yedek alındı.\n' +
      'İzleme tarihi gibi eksik bilgiler uydurulmadı; mevcut alanlarınız korundu.'
    );
  }

  // Uygunluk düzeltmelerini ayrı anahtardan yükle (bozuksa ham veri korunur).
  const uySonuc = loadUygunluk();
  if (uySonuc && uySonuc.ok === false) {
    alert('Uygunluk verisi uyarısı: ' + uySonuc.error);
  }

  // Tür panelini doldur (19 ana tür, çoklu seçim).
  const turleriDoldur = () => {
    const panel = $('turPanel');
    panel.innerHTML = '';
    ANA_TURLER.forEach((t) => {
      const sayi = catalog.filter((x) => (x.turler || []).includes(t)).length;
      const lab = document.createElement('label');
      lab.className = 'coklu-satir';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = t;
      cb.addEventListener('change', () => { turBtnGuncelle(); render(); });
      const span = document.createElement('span');
      span.textContent = t;
      const em = document.createElement('em');
      em.textContent = sayi;
      lab.append(cb, span, em);
      panel.append(lab);
    });
  };

  // Buton etiketini seçime göre güncelle.
  const turBtnGuncelle = () => {
    const n = seciliTurler().length;
    const s = sinifsizAktif();
    const parca = [];
    if (n) parca.push(n + ' tür');
    if (s) parca.push('sınıflandırılmamış');
    $('turBtn').textContent = parca.length ? parca.join(' + ') + ' ▾' : 'Tüm türler ▾';
  };

  turleriDoldur();
  $('turBtn').onclick = (e) => { e.stopPropagation(); $('turPanel').classList.toggle('hidden'); };

  // Etiket panelini doldur (6 etiket, çoklu seçim).
  const etiketleriDoldur = () => {
    const panel = $('etPanel');
    panel.innerHTML = '';
    ETIKETLER.forEach((t) => {
      const sayi = catalog.filter((x) => (x.etiketler || []).includes(t)).length;
      const lab = document.createElement('label');
      lab.className = 'coklu-satir';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = t;
      cb.addEventListener('change', () => { etBtnGuncelle(); render(); });
      const span = document.createElement('span');
      span.textContent = t;
      const em = document.createElement('em');
      em.textContent = sayi;
      lab.append(cb, span, em);
      panel.append(lab);
    });
  };
  const etBtnGuncelle = () => {
    const n = seciliEtiketler().length;
    $('etBtn').textContent = n ? n + ' etiket ▾' : 'Tüm etiketler ▾';
    $('etBtn').setAttribute('aria-expanded', String(!$('etPanel').classList.contains('hidden')));
  };
  etiketleriDoldur();
  $('etBtn').onclick = (e) => {
    e.stopPropagation();
    const acik = $('etPanel').classList.toggle('hidden');
    $('etBtn').setAttribute('aria-expanded', String(!acik));
  };

  // Özellik çipleri (ortam / bicim / animasyonGelenegi). Tıklama → seç/deseç.
  document.querySelectorAll('#filtreEk .cip').forEach((b) => {
    b.onclick = () => {
      const yeni = b.getAttribute('aria-pressed') !== 'true';
      b.setAttribute('aria-pressed', String(yeni));
      render();
    };
  });

  document.addEventListener('click', (e) => {
    if (!$('turKutu').contains(e.target)) $('turPanel').classList.add('hidden');
    if (!$('etKutu').contains(e.target)) $('etPanel').classList.add('hidden');
    etBtnGuncelle();
  });

  ['q', 'kind', 'status', 'sort'].forEach((id) => $(id).addEventListener(id === 'q' ? 'input' : 'change', render));
  $('sinifsiz').addEventListener('change', () => { turBtnGuncelle(); render(); });
  $('reset').onclick = () => {
    ['q', 'kind', 'status'].forEach((id) => ($(id).value = ''));
    $('sinifsiz').checked = false;
    document.querySelectorAll('#turPanel input[type="checkbox"]').forEach((c) => (c.checked = false));
    document.querySelectorAll('#etPanel input[type="checkbox"]').forEach((c) => (c.checked = false));
    document.querySelectorAll('#filtreEk .cip').forEach((b) => b.setAttribute('aria-pressed', 'false'));
    $('sort').value = 'az';
    turBtnGuncelle();
    etBtnGuncelle();
    render();
  };
  $('pdf').onclick = () => window.print();
  $('json').onclick = disaAktarJSON;
  $('csv').onclick = disaAktarCSV;

  // İçe aktarma: dosya seç → önizleme → Birleştir/Değiştir/İptal.
  $('restore').onclick = () => $('file').click();
  $('file').onchange = (e) => {
    const f = e.target.files[0];
    if (f) iceAktarmaDosyaSecildi(f);
    e.target.value = '';
  };
  $('iceIptal').onclick = () => { bekleyenAnaliz = null; modalGizle('iceModal'); };
  $('iceBirlestir').onclick = () => iceAktarmaUygula('birlestir');
  $('iceDegistir').onclick = () => iceAktarmaUygula('degistir');

  // Geri al.
  const geriAlBtn = $('geriAl');
  if (geriAlBtn) {
    geriAlBtn.onclick = () => (hasBackup() ? modalGoster('geriAlModal') : alert('Geri alınacak yedek yok.'));
  }
  $('geriAlIptal').onclick = () => modalGizle('geriAlModal');
  $('geriAlOnay').onclick = () => {
    modalGizle('geriAlModal');
    // Kullanıcı verisi, uygunluk ve migration meta'sı journal ile BİRLİKTE geri alınır.
    const r = geriAl();
    if (r.ok) {
      // Kilidi kaldır: tutarlı duruma dönüldü.
      setVeriKilitli(false);
      loadState();
      loadUygunluk();
      renderStats();
      render();
      alert('Önceki duruma geri dönüldü.' + (r.uygunlukVar ? '' : ' (Uygunluk yedeği yoktu; mevcut uygunluk verisi korundu.)'));
    } else {
      alert('Geri alınamadı: ' + r.hata);
    }
  };

  renderStats();
  render();
}

document.addEventListener('DOMContentLoaded', baslat);

// Aşama 3.1 — Tür/alt tür/etiket taksonomisi ve saf doğrulama (DOM ve localStorage bağımsız).
// Bu modül HİÇBİR katalog kaydını değiştirmez; yalnızca sabitleri tanımlar ve
// verilen bir kaydı doğrular. Eski `genre` alanına dokunmaz.

// --- Ana türler (19) ---
const ANA_TURLER = [
  'Aksiyon', 'Aile', 'Bilim kurgu', 'Biyografi', 'Dram', 'Fantastik', 'Felaket',
  'Gerilim', 'Gizem', 'Komedi', 'Korku', 'Macera', 'Müzik', 'Romantik',
  'Savaş', 'Spor', 'Suç', 'Tarih', 'Western',
];

// --- Alt türler (6) ve bağlı oldukları ana tür (merkezi tek kaynak) ---
const ALT_TUR_ANA = {
  'Gangster': 'Suç',
  'Polisiye': 'Suç',
  'Dedektif': 'Gizem',
  'Psikolojik': 'Gerilim',
  'Casusluk': 'Aksiyon',
  'Hayatta kalma': 'Felaket',
};
const ALT_TURLER = Object.keys(ALT_TUR_ANA);

// --- Etiketler (tür değil) ---
const ETIKETLER = [
  'Klasik', 'Dünya sineması', 'Bağımsız/Sanat sineması', 'Gerçek olay',
  'Okul', 'Gençlik',
];

// --- Ayrı özellikler için izin verilen değerler ---
// ortam: kayıtlarda alan YOKSA ortam BİLİNMİYOR demektir; "Canlı aksiyon" olarak
// VARSAYILMAZ (bilinmeyeni kesin bilgi gibi göstermemek için). Filtrede bu durum
// ayrı bir seçenekle (ORTAM_BELIRTILMEMIS) sunulur.
const ORTAM_DEGERLERI = ['Animasyon', 'Canlı aksiyon'];
const ORTAM_BELIRTILMEMIS = 'Belirtilmemiş';
const ANIMASYON_GELENEGI_DEGERLERI = ['Anime', 'Batı'];
const BICIM_DEGERLERI = ['Mini dizi'];

// --- Temel üyelik yardımcıları ---
function anaTurGecerliMi(t) {
  return ANA_TURLER.includes(t);
}
function altTurGecerliMi(a) {
  return ALT_TURLER.includes(a);
}
function etiketGecerliMi(e) {
  return ETIKETLER.includes(e);
}
function ortamGecerliMi(o) {
  return ORTAM_DEGERLERI.includes(o);
}
// Kayıtta ortam alanı yoksa/boşsa ortam BİLİNMİYOR demektir (Canlı aksiyon DEĞİL).
function ortamBelirtilmemisMi(kayit) {
  return !kayit || !kayit.ortam;
}
function animasyonGelenegiGecerliMi(g) {
  return ANIMASYON_GELENEGI_DEGERLERI.includes(g);
}
function bicimGecerliMi(b) {
  return BICIM_DEGERLERI.includes(b);
}

// Bir alt türün bağlı olduğu ana türü döndürür (yoksa undefined).
function altTurunAnaTuru(altTur) {
  return ALT_TUR_ANA[altTur];
}

// Dizinin her elemanı geçerli mi + tekil mi kontrol eder.
function _diziKontrol(deger, gecerliMi) {
  const hatalar = [];
  if (!Array.isArray(deger)) {
    hatalar.push('dizi değil');
    return { hatalar, temiz: [] };
  }
  const temiz = [];
  for (const v of deger) {
    if (!gecerliMi(v)) hatalar.push('geçersiz değer: ' + JSON.stringify(v));
    else if (temiz.includes(v)) hatalar.push('tekrar eden değer: ' + JSON.stringify(v));
    else temiz.push(v);
  }
  return { hatalar, temiz };
}

// Bir katalog kaydını doğrular. Kaydı DEĞİŞTİRMEZ.
// Dönen: { ok, hatalar, uyarilar, gozdenGecirGerekli, temiz }
//   ok=false  → doğrulama hatası (geçersiz ana tür, boş turler+gozdenGecir yok, vb.)
//   uyarilar  → hata değil; ör. alt türün ana türü turler'de yok → gozdenGecir gerekir
function kayitDogrula(kayit) {
  const hatalar = [];
  const uyarilar = [];
  const temiz = {};

  if (!kayit || typeof kayit !== 'object' || Array.isArray(kayit)) {
    return { ok: false, hatalar: ['kayıt nesne değil'], uyarilar: [], gozdenGecirGerekli: false, temiz: {} };
  }

  const gozdenGecir = kayit.gozdenGecir === true;

  // --- turler (ana türler) ---
  if (!('turler' in kayit)) {
    hatalar.push('turler alanı yok');
  } else if (!Array.isArray(kayit.turler)) {
    hatalar.push('turler dizi değil');
  } else {
    const gecersiz = kayit.turler.filter((t) => !anaTurGecerliMi(t));
    if (gecersiz.length) hatalar.push('geçersiz ana tür: ' + JSON.stringify(gecersiz));
    const tekrar = kayit.turler.filter((t, i) => kayit.turler.indexOf(t) !== i);
    if (tekrar.length) hatalar.push('tekrar eden ana tür: ' + JSON.stringify([...new Set(tekrar)]));
    const gecerli = kayit.turler.filter(anaTurGecerliMi);
    temiz.turler = [...new Set(gecerli)];

    // Boş turler yalnızca gozdenGecir:true ile geçerlidir.
    if (kayit.turler.length === 0 && !gozdenGecir) {
      hatalar.push('turler boş ancak gozdenGecir:true değil');
    }
  }

  // --- altTurler ---
  if ('altTurler' in kayit) {
    const r = _diziKontrol(kayit.altTurler, altTurGecerliMi);
    r.hatalar.forEach((h) => hatalar.push('altTurler: ' + h));
    temiz.altTurler = r.temiz;
    // Her alt türün ana türü turler içinde olmalı; değilse reddetme, gozdenGecir gerekir.
    const turler = Array.isArray(kayit.turler) ? kayit.turler : [];
    for (const a of r.temiz) {
      const ana = ALT_TUR_ANA[a];
      if (!turler.includes(ana)) {
        uyarilar.push('alt tür "' + a + '" için ana tür "' + ana + '" turler içinde yok');
      }
    }
  }

  // --- etiketler ---
  if ('etiketler' in kayit) {
    const r = _diziKontrol(kayit.etiketler, etiketGecerliMi);
    r.hatalar.forEach((h) => hatalar.push('etiketler: ' + h));
    temiz.etiketler = r.temiz;
  }

  // --- ortam ---
  if ('ortam' in kayit && !ortamGecerliMi(kayit.ortam)) {
    hatalar.push('geçersiz ortam: ' + JSON.stringify(kayit.ortam));
  }

  // --- animasyonGelenegi ---
  if ('animasyonGelenegi' in kayit) {
    if (!animasyonGelenegiGecerliMi(kayit.animasyonGelenegi)) {
      hatalar.push('geçersiz animasyonGelenegi: ' + JSON.stringify(kayit.animasyonGelenegi));
    } else if (kayit.ortam !== 'Animasyon') {
      uyarilar.push('animasyonGelenegi yalnızca ortam:Animasyon iken anlamlıdır');
    }
  }

  // --- bicim ---
  if ('bicim' in kayit && !bicimGecerliMi(kayit.bicim)) {
    hatalar.push('geçersiz bicim: ' + JSON.stringify(kayit.bicim));
  }

  const gozdenGecirGerekli = uyarilar.length > 0;
  return { ok: hatalar.length === 0, hatalar, uyarilar, gozdenGecirGerekli, temiz };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    ANA_TURLER, ALT_TURLER, ALT_TUR_ANA, ETIKETLER,
    ORTAM_DEGERLERI, ORTAM_BELIRTILMEMIS, ANIMASYON_GELENEGI_DEGERLERI, BICIM_DEGERLERI,
    anaTurGecerliMi, altTurGecerliMi, etiketGecerliMi,
    ortamGecerliMi, ortamBelirtilmemisMi, animasyonGelenegiGecerliMi, bicimGecerliMi,
    altTurunAnaTuru, kayitDogrula,
  };
}

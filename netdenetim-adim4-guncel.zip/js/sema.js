// Şema sürümü ve migration altyapısı (saf; DOM ve localStorage kullanmaz).
// Amaç: mevcut kullanıcı verisinin gelecekte güvenle genişletilebilmesi.
//
// Tasarım kararı: Aşama 2'de kullanıcı kaydının şekli (watched/favorite/rating/rank)
// KORUNUR. Sürüm bilgisi ayrı bir meta anahtarında tutulur; böylece eski veriler,
// mevcut dışa/içe aktarma akışı ve Aşama 1 davranışları bozulmaz.
// İzleme durumu (`status`) `watched` alanından TÜRETİLİR; state'e yazılmaz ve
// hiçbir zaman izleme tarihi uydurulmaz.

const GUNCEL_SEMA = 2;
const SEMA_META_KEY = 'personal-film-series-archive-v1__meta';
const MIGRATION_BACKUP_KEY = 'personal-film-series-archive-v1__migration-backup';
const BILINEN_ALANLAR = ['watched', 'favorite', 'rating', 'rank'];

// İzleme durumunu mevcut alanlardan türetir. Tarih bilgisi içermez.
function durumTuret(kayit) {
  if (!kayit || typeof kayit !== 'object') return 'izlenecek';
  if (kayit.watched === true) return 'izlendi';
  if (kayit.watched === false) return 'izlenmedi';
  return 'izlenecek';
}

// Bir kaydı inceler. Hiçbir alanı silmez veya değiştirmez; yalnızca raporlar.
function kayitIncele(id, kayit) {
  if (!kayit || typeof kayit !== 'object' || Array.isArray(kayit)) {
    return { id, sorunlar: [{ id, field: '(kayıt)', value: kayit, reason: 'kayıt nesne değil' }], bilinmeyen: [] };
  }
  const sorunlar = [];
  if ('watched' in kayit && typeof kayit.watched !== 'boolean') {
    sorunlar.push({ id, field: 'watched', value: kayit.watched, reason: 'boolean değil' });
  }
  if ('favorite' in kayit && typeof kayit.favorite !== 'boolean') {
    sorunlar.push({ id, field: 'favorite', value: kayit.favorite, reason: 'boolean değil' });
  }
  if ('rating' in kayit && !(Number.isInteger(kayit.rating) && kayit.rating >= 1 && kayit.rating <= 10)) {
    sorunlar.push({ id, field: 'rating', value: kayit.rating, reason: '1-10 arası tamsayı değil' });
  }
  if ('rank' in kayit && !(Number.isInteger(kayit.rank) && kayit.rank >= 1)) {
    sorunlar.push({ id, field: 'rank', value: kayit.rank, reason: 'pozitif tamsayı değil' });
  }
  const bilinmeyen = Object.keys(kayit).filter((a) => !BILINEN_ALANLAR.includes(a));
  return { id, sorunlar, bilinmeyen };
}

// Mevcut state ve meta için migration planı üretir. Hiçbir şeyi DEĞİŞTİRMEZ.
// Dönen: { ok, error?, gerekti, fromVersion, toVersion, yeniMeta, rapor }
function migrationPlanla(state, meta) {
  const guvenliState = state && typeof state === 'object' && !Array.isArray(state) ? state : {};

  let surum = 1;
  if (meta === null) {
    // Çağıran null ile "meta okunamadı/bozuk" durumunu bildirir.
    return {
      ok: false,
      error: 'Bozuk şema meta verisi. Hiçbir veri değiştirilmedi.',
      fromVersion: null,
      toVersion: GUNCEL_SEMA,
    };
  }
  if (meta && typeof meta === 'object' && !Array.isArray(meta)) {
    if ('_schema' in meta) {
      if (!Number.isInteger(meta._schema) || meta._schema < 1) {
        return {
          ok: false,
          error: 'Bozuk şema meta verisi (_schema geçersiz). Hiçbir veri değiştirilmedi.',
          fromVersion: null,
          toVersion: GUNCEL_SEMA,
        };
      }
      surum = meta._schema;
    }
  }

  if (surum > GUNCEL_SEMA) {
    return {
      ok: false,
      error: 'Desteklenmeyen şema sürümü: ' + surum + ' (bu sürüm en fazla ' + GUNCEL_SEMA + ' destekler). Hiçbir veri değiştirilmedi.',
      fromVersion: surum,
      toVersion: GUNCEL_SEMA,
    };
  }

  const rapor = { toplamKayit: 0, sorunluKayit: 0, gecersizDegerler: [], bilinmeyenAlanlar: [] };
  for (const [id, kayit] of Object.entries(guvenliState)) {
    rapor.toplamKayit++;
    const inc = kayitIncele(id, kayit);
    if (inc.sorunlar.length) {
      rapor.sorunluKayit++;
      rapor.gecersizDegerler.push(...inc.sorunlar);
    }
    if (inc.bilinmeyen.length) rapor.bilinmeyenAlanlar.push({ id, alanlar: inc.bilinmeyen });
  }

  if (surum === GUNCEL_SEMA) {
    return { ok: true, gerekti: false, fromVersion: surum, toVersion: GUNCEL_SEMA, yeniMeta: meta, rapor };
  }

  // 1 → 2: kayıt şekli korunur; yalnızca sürüm meta verisi güncellenir.
  const yeniMeta = { _schema: GUNCEL_SEMA, migratedFrom: surum };
  return { ok: true, gerekti: true, fromVersion: surum, toVersion: GUNCEL_SEMA, yeniMeta, rapor };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { durumTuret, kayitIncele, migrationPlanla, GUNCEL_SEMA, SEMA_META_KEY, MIGRATION_BACKUP_KEY, BILINEN_ALANLAR };
}

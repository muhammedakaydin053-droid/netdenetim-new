// Kullanıcı verisi katmanı: LocalStorage, yedekleme, geri alma.
// Anahtar ve mevcut alanlar (watched, favorite, rating, rank) korunur.

const KEY = 'personal-film-series-archive-v1';
const BACKUP_KEY = 'personal-film-series-archive-v1__backup';
// İçerik uygunluğu kullanıcı düzeltmeleri AYRI anahtarda tutulur (kaynak verisini ezmez).
const UYGUNLUK_KEY = 'personal-film-series-archive-v1__uygunluk';
const UYGUNLUK_BACKUP_KEY = 'personal-film-series-archive-v1__uygunluk-backup';
// İşlem günlüğü (journal): iki anahtarlı yazımın yarıda kalma durumunu kurtarmak için.
const JOURNAL_KEY = 'personal-film-series-archive-v1__journal';

let state = {};
let uygunlukState = {};
// Journal kurtarma başarısız olursa true olur; veri değiştiren işlemleri kilitler.
let veriKilitli = false;

function setVeriKilitli(v) { veriKilitli = !!v; }
function veriKilitliMi() { return veriKilitli; }

// Uygunluk düzeltmelerini okur; bozuksa boş döner ve HAM veriyi SİLMEZ.
function loadUygunluk() {
  const raw = localStorage.getItem(UYGUNLUK_KEY);
  if (raw === null) { uygunlukState = {}; return { ok: true, durum: 'temiz' }; }
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      uygunlukState = parsed;
      return { ok: true, durum: 'guncel' };
    }
    uygunlukState = {};
    return { ok: false, error: 'Uygunluk verisi nesne değil; ham veri korundu.' };
  } catch (e) {
    uygunlukState = {};
    return { ok: false, error: 'Uygunluk verisi bozuk JSON; ham veri korundu.' };
  }
}

// Bir kaydın GEÇERLİ uygunluk verisini döndürür (kaynak temel + kullanıcı düzeltmesi).
function uygunlukGet(id) {
  return birlestir(UYGUNLUK_TEMEL[id], uygunlukState[id]);
}

// Kullanıcı düzeltmesi yazar. Kaynak verisine dokunmaz.
function uygunlukDuzelt(id, alan, deger) {
  if (veriKilitli) return null; // Kurtarma başarısızsa değişiklik yok.
  const kayit = { ...(uygunlukState[id] || {}), id };
  if (alan === 'kategori') {
    kayit.kategoriler = { ...(kayit.kategoriler || {}), [deger.kategori]: deger.seviye };
  } else if (alan === 'kullaniciNotu') {
    kayit.kullaniciNotu = deger;
  } else if (alan === 'durum') {
    kayit.durum = deger;
  } else {
    kayit[alan] = deger;
  }
  uygunlukState[id] = kayit;
  uygunlukKaydet();
  return kayit;
}

function uygunlukKaydet() {
  localStorage.setItem(UYGUNLUK_KEY, JSON.stringify(uygunlukState));
}

// Bir kategori düzeltmesini kaldırır; ilgili kategori KAYNAK değerine döner.
// Kullanıcı kaydı tamamen boşalırsa anahtar silinir → kaynak veri aynen geçerli olur.
// Dönen: kalan kullanıcı kaydı veya null (kayıt tamamen kaldırıldıysa).
function uygunlukDuzeltmeKaldir(id, kategori) {
  const kayit = uygunlukState[id];
  if (!kayit || typeof kayit !== 'object') return null;
  if (kayit.kategoriler && Object.prototype.hasOwnProperty.call(kayit.kategoriler, kategori)) {
    delete kayit.kategoriler[kategori];
  }
  if (kayit.kategoriler && Object.keys(kayit.kategoriler).length === 0) delete kayit.kategoriler;
  const bos = !kayit.kategoriler && !kayit.kullaniciNotu && !kayit.durum && !kayit.sezonlar;
  if (bos) {
    delete uygunlukState[id];
    if (Object.keys(uygunlukState).length === 0) localStorage.removeItem(UYGUNLUK_KEY);
    else uygunlukKaydet();
    return null;
  }
  uygunlukState[id] = kayit;
  uygunlukKaydet();
  return kayit;
}

// Bir kaydın TÜM kullanıcı düzeltmelerini kaldırır (kaynak veriye tam dönüş).
function uygunlukSifirla(id) {
  if (!(id in uygunlukState)) return false;
  delete uygunlukState[id];
  if (Object.keys(uygunlukState).length === 0) localStorage.removeItem(UYGUNLUK_KEY);
  else uygunlukKaydet();
  return true;
}

// Uygunluk katmanının otomatik yedeğini alır (içe aktarma öncesi).
function uygunlukBackupAl() {
  try {
    localStorage.setItem(UYGUNLUK_BACKUP_KEY, JSON.stringify(uygunlukState));
    return true;
  } catch (e) {
    return false;
  }
}

function uygunlukGeriAl() {
  const raw = localStorage.getItem(UYGUNLUK_BACKUP_KEY);
  if (raw === null) return false;
  let parsed;
  try { parsed = JSON.parse(raw); } catch (e) { return false; }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return false;
  try {
    localStorage.setItem(UYGUNLUK_KEY, JSON.stringify(parsed));
  } catch (e) { return false; }
  uygunlukState = parsed;
  return true;
}

function getUygunlukRaw() {
  return uygunlukState;
}
function setUygunlukState(obj) {
  uygunlukState = obj && typeof obj === 'object' && !Array.isArray(obj) ? obj : {};
}

// ============================================================
// İki anahtarlı (KEY + UYGUNLUK_KEY) yazım için journal tabanlı atomiklik.
// Not: localStorage'da GERÇEK çok-anahtarlı atomiklik YOKTUR. İki ayrı setItem
// çağrısı arasında çökme olursa tutarsızlık oluşabilir. Bu yüzden:
//   1) Önce journal'a her iki yeni değer + eski değerler yazılır (commit noktası).
//   2) Sonra iki anahtar sırayla yazılır.
//   3) Başarıda journal silinir; hatada her iki anahtar eski hâline döndürülür.
//   4) Açılışta yarım kalmış journal bulunursa kurtarma yapılır (bkz. journalKurtar).
// ============================================================

function journalYaz(kayit) {
  localStorage.setItem(JOURNAL_KEY, JSON.stringify(kayit));
}

function journalTemizle() {
  try { localStorage.removeItem(JOURNAL_KEY); } catch (e) { /* yok say */ }
}

function journalOku() {
  const raw = localStorage.getItem(JOURNAL_KEY);
  if (raw === null) return null;
  try {
    const p = JSON.parse(raw);
    return p && typeof p === 'object' && !Array.isArray(p) ? p : null;
  } catch (e) {
    return null;
  }
}

// İki anahtarı journal ile güvenli biçimde yazar.
// Dönen: { ok, kurtarildi?, hata? }
function ikiAnahtarYaz(yeniKullanici, yeniUygunluk) {
  const eskiKullanici = localStorage.getItem(KEY);
  const eskiUygunluk = localStorage.getItem(UYGUNLUK_KEY);
  // 1) Commit noktası: journal. Yazılamazsa hiçbir anahtara dokunma.
  try {
    journalYaz({ kullanici: yeniKullanici, uygunluk: yeniUygunluk, eskiKullanici, eskiUygunluk, ts: Date.now() });
  } catch (e) {
    return { ok: false, hata: 'İşlem günlüğü yazılamadı; hiçbir veri değiştirilmedi.' };
  }
  // 2) İki anahtarı yaz.
  let kullaniciYazildi = false;
  try {
    localStorage.setItem(KEY, JSON.stringify(yeniKullanici));
    kullaniciYazildi = true;
    localStorage.setItem(UYGUNLUK_KEY, JSON.stringify(yeniUygunluk));
  } catch (e) {
    // 3a) Hata: yazılmış olanları eski hâline döndürmeyi dene.
    let geriAlindi = true;
    if (kullaniciYazildi) {
      try { if (eskiKullanici === null) localStorage.removeItem(KEY); else localStorage.setItem(KEY, eskiKullanici); }
      catch (e2) { geriAlindi = false; }
    }
    try { if (eskiUygunluk === null) localStorage.removeItem(UYGUNLUK_KEY); else localStorage.setItem(UYGUNLUK_KEY, eskiUygunluk); }
    catch (e3) { geriAlindi = false; }
    if (geriAlindi) {
      journalTemizle();
      return { ok: false, hata: 'Yazma hatası oluştu; her iki katman da eski hâline döndürüldü.' };
    }
    // 3b) Geri alma da başarısız: journal'ı BIRAK (açılışta kurtarılacak) ve açıkça bildir.
    return { ok: false, kurtarildi: false, hata: 'Kritik: yazma ve geri alma başarısız. Tutarsız durum oluştu; işlem günlüğü bırakıldı, sayfa yeniden açıldığında kurtarılacak.' };
  }
  // 4) Başarı: journal temizle.
  journalTemizle();
  return { ok: true };
}

// Açılışta yarım kalmış journal varsa tutarlılığı sağlar.
// Yeni değerler mevcutsa tamamlar; aksi hâlde eski değerlere döndürür.
// `tur:'geri-al'` kayıtlarında migration meta verisi de geri yüklenir.
// Dönen: null (journal yok) | { kurtarildi, detay }
function journalKurtar() {
  const j = journalOku();
  if (!j) return null;
  const geriAlTuru = j.tur === 'geri-al';
  const suAnKullanici = localStorage.getItem(KEY);
  const suAnUygunluk = localStorage.getItem(UYGUNLUK_KEY);
  const yeniK = JSON.stringify(j.kullanici);
  const yeniU = JSON.stringify(j.uygunluk);
  const eskiK = j.eskiKullanici === null ? null : j.eskiKullanici;
  const eskiU = j.eskiUygunluk === null ? null : j.eskiUygunluk;

  try {
    if (suAnKullanici === yeniK && suAnUygunluk === yeniU) {
      // Her iki anahtar da yeni değerde → işlem tamamlanmıştı, yalnızca journal silinmemiş.
      journalTemizle();
      return { kurtarildi: 'tamamlandi', detay: 'İşlem günlüğü temizlendi.' };
    }
    // Yarım kalmış: eski değerlere geri döndür (en güvenli, kayıpsız seçenek).
    if (eskiK === null) localStorage.removeItem(KEY); else localStorage.setItem(KEY, eskiK);
    if (eskiU === null) localStorage.removeItem(UYGUNLUK_KEY); else localStorage.setItem(UYGUNLUK_KEY, eskiU);
    if (geriAlTuru) {
      // Geri alma sırasında meta sıfırlanıyordu; eski meta hâline döndür.
      if (j.eskiMeta === null || j.eskiMeta === undefined) localStorage.removeItem(SEMA_META_KEY);
      else localStorage.setItem(SEMA_META_KEY, j.eskiMeta);
    }
    journalTemizle();
    return { kurtarildi: 'geri-alindi', detay: 'Yarım kalan işlem geri alındı; önceki veri korundu.' };
  } catch (e) {
    return { kurtarildi: 'basarisiz', detay: 'Kurtarma yazımı başarısız; işlem günlüğü korundu.' };
  }
}

// Açılışta iki katmanın gerçekten tutarlı olduğunu doğrular (ham okuma karşılaştırması).
// Dönen: { tutarli, neden? }
function ikiKatmanTutarliMi(beklenenKullanici, beklenenUygunluk) {
  const suAnKullanici = localStorage.getItem(KEY);
  const suAnUygunluk = localStorage.getItem(UYGUNLUK_KEY);
  const bk = beklenenKullanici === null ? null : JSON.stringify(beklenenKullanici);
  const bu = beklenenUygunluk === null ? null : JSON.stringify(beklenenUygunluk);
  if (suAnKullanici !== bk) return { tutarli: false, neden: 'Kullanıcı verisi beklenen değerle eşleşmiyor.' };
  if (suAnUygunluk !== bu) return { tutarli: false, neden: 'Uygunluk verisi beklenen değerle eşleşmiyor.' };
  return { tutarli: true };
}

// Geri almayı iki anahtar için journal ile güvenli biçimde uygular.
// Kullanıcı verisi yedeği (BACKUP_KEY) ve uygunluk yedeği (UYGUNLUK_BACKUP_KEY)
// BİRLİKTE geri yüklenir; iki anahtardan biri yazılamazsa diğeri eski/yeni hâlde
// kalmaz (ikisi birlikte eski hâline döner veya kurtarılır).
// Dönen: { ok, kullaniciVar, uygunlukVar, hata?, kurtarildi? }
function geriAl() {
  // Yedekleri önce belleğe al (yazma yapmadan).
  const kullaniciYedekRaw = localStorage.getItem(BACKUP_KEY);
  const uygunlukYedekRaw = localStorage.getItem(UYGUNLUK_BACKUP_KEY);
  const kullaniciVar = kullaniciYedekRaw !== null;
  const uygunlukVar = uygunlukYedekRaw !== null;
  if (!kullaniciVar) return { ok: false, kullaniciVar, uygunlukVar, hata: 'Geri alınacak kullanıcı yedeği yok.' };

  let kullaniciYedek, uygunlukYedek = null;
  try {
    kullaniciYedek = JSON.parse(kullaniciYedekRaw);
  } catch (e) {
    return { ok: false, kullaniciVar, uygunlukVar, hata: 'Kullanıcı yedeği bozuk JSON; geri alınmadı.' };
  }
  if (!kullaniciYedek || typeof kullaniciYedek !== 'object' || Array.isArray(kullaniciYedek)) {
    return { ok: false, kullaniciVar, uygunlukVar, hata: 'Kullanıcı yedeği nesne değil; geri alınmadı.' };
  }
  if (uygunlukVar) {
    try {
      uygunlukYedek = JSON.parse(uygunlukYedekRaw);
    } catch (e) {
      return { ok: false, kullaniciVar, uygunlukVar, hata: 'Uygunluk yedeği bozuk JSON; geri alınmadı.' };
    }
    if (!uygunlukYedek || typeof uygunlukYedek !== 'object' || Array.isArray(uygunlukYedek)) {
      return { ok: false, kullaniciVar, uygunlukVar, hata: 'Uygunluk yedeği nesne değil; geri alınmadı.' };
    }
  } else {
    // Uygunluk yedeği yoksa mevcut uygunluk verisini (HAM) koru (kayıp olmasın).
    try {
      uygunlukYedek = JSON.parse(localStorage.getItem(UYGUNLUK_KEY) || '{}');
    } catch (e) {
      uygunlukYedek = {};
    }
    if (!uygunlukYedek || typeof uygunlukYedek !== 'object' || Array.isArray(uygunlukYedek)) uygunlukYedek = {};
  }

  // Migration meta verisi sıfırlanmalı ki geri alınan veri yeniden değerlendirilsin.
  // Bunu journal'dan ÖNCE al ve yazımı da journal kapsamına al.
  const eskiMeta = localStorage.getItem(SEMA_META_KEY);

  // Journal commit noktası: hem kullanıcı hem uygunluk hem meta bilgisi.
  try {
    journalYaz({
      tur: 'geri-al',
      kullanici: kullaniciYedek,
      uygunluk: uygunlukYedek,
      eskiKullanici: localStorage.getItem(KEY),
      eskiUygunluk: localStorage.getItem(UYGUNLUK_KEY),
      eskiMeta,
      metaYaz: null,
      ts: Date.now(),
    });
  } catch (e) {
    return { ok: false, kullaniciVar, uygunlukVar, hata: 'İşlem günlüğü yazılamadı; geri alma yapılmadı.' };
  }

  // Yazım: KEY, UYGUNLUK_KEY ve meta.
  try {
    localStorage.setItem(KEY, JSON.stringify(kullaniciYedek));
    localStorage.setItem(UYGUNLUK_KEY, JSON.stringify(uygunlukYedek));
    localStorage.removeItem(SEMA_META_KEY); // migration yeniden değerlendirilsin
  } catch (e) {
    // Geri alma denemesi: her iki anahtarı ve meta'yı eski hâle döndür.
    let geriAlindi = true;
    try {
      const j = JSON.parse(localStorage.getItem(JOURNAL_KEY) || '{}');
      const eskiK = j.eskiKullanici;
      const eskiU = j.eskiUygunluk;
      if (eskiK === null || eskiK === undefined) localStorage.removeItem(KEY); else localStorage.setItem(KEY, eskiK);
      if (eskiU === null || eskiU === undefined) localStorage.removeItem(UYGUNLUK_KEY); else localStorage.setItem(UYGUNLUK_KEY, eskiU);
      if (eskiMeta === null) localStorage.removeItem(SEMA_META_KEY); else localStorage.setItem(SEMA_META_KEY, eskiMeta);
    } catch (e2) { geriAlindi = false; }
    if (geriAlindi) {
      journalTemizle();
      return { ok: false, kullaniciVar, uygunlukVar, hata: 'Geri alma sırasında yazma hatası; her iki katman da eski hâline döndürüldü.' };
    }
    return { ok: false, kullaniciVar, uygunlukVar, kurtarildi: false, hata: 'Kritik: geri alma ve geri döndürme başarısız. Tutarsız durum; işlem günlüğü bırakıldı, sonraki açılışta kurtarılacak.' };
  }

  journalTemizle();
  return { ok: true, kullaniciVar, uygunlukVar };
}

// Ham state'i okur (biçim doğrulaması yapar ama değiştirmez).
function okuHam() {
  const raw = localStorage.getItem(KEY);
  if (raw === null) return {};
  const parsed = JSON.parse(raw); // bozuksa hata yükselir; çağıran yakalar
  return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
}

// Migration meta verisini okur; bozuksa null döner.
function okuMeta() {
  const raw = localStorage.getItem(SEMA_META_KEY);
  if (raw === null) return {};
  try {
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
  } catch (e) {
    return null; // bozuk meta → migrationPlanla reddeder
  }
}

// LocalStorage verisini yükler ve gerekiyorsa şema migration'ı uygular.
// Dönen: { ok, error?, durum? }  durum: 'temiz' | 'yeni' | 'migrate-edildi' | 'guncel'
function loadState() {
  let ham;
  try {
    ham = okuHam();
  } catch (e) {
    // Bozuk JSON: sessizce dönüştürme. Eski veriyi olduğu gibi bırak.
    state = {};
    return { ok: false, error: 'LocalStorage verisi bozuk JSON. Hiçbir veri değiştirilmedi.' };
  }

  const meta = okuMeta();
  const plan = migrationPlanla(ham, meta);

  if (!plan.ok) {
    // Desteklenmeyen/bozuk şema: veriyi değiştirme, bellekte olduğu gibi tut.
    state = ham;
    return { ok: false, error: plan.error };
  }

  if (!plan.gerekti) {
    state = ham;
    return { ok: true, durum: Object.keys(ham).length ? 'guncel' : 'temiz' };
  }

  // Taşınacak kayıt yoksa gereksiz migration/yedek yapma.
  if (Object.keys(ham).length === 0) {
    state = ham;
    return { ok: true, durum: 'temiz' };
  }

  // Migration gerekiyor. Önce yedek al; alınamazsa başlatma.
  if (!migrationBackupRaw(ham)) {
    state = ham;
    return { ok: false, error: 'Migration öncesi yedek alınamadı. Hiçbir veri değiştirilmedi.' };
  }

  // Atomik yazma: state değişmez, yalnızca meta yazılır. Hata olursa state korunur.
  const eskiMeta = localStorage.getItem(SEMA_META_KEY);
  try {
    localStorage.setItem(SEMA_META_KEY, JSON.stringify(plan.yeniMeta));
  } catch (e) {
    try {
      if (eskiMeta === null) localStorage.removeItem(SEMA_META_KEY);
      else localStorage.setItem(SEMA_META_KEY, eskiMeta);
    } catch (e2) { /* yok say */ }
    state = ham;
    return { ok: false, error: 'Migration sırasında yazma hatası. Mevcut veri korundu.' };
  }

  state = ham;
  return { ok: true, durum: 'migrate-edildi', rapor: plan.rapor, fromVersion: plan.fromVersion, toVersion: plan.toVersion };
}

// Verilen ham nesneyi yedek anahtarına yazar.
function backupRaw(veri) {
  try {
    localStorage.setItem(BACKUP_KEY, JSON.stringify(veri));
    return true;
  } catch (e) {
    return false;
  }
}

// Migration öncesi yedeği ayrı anahtara yazar (içe aktarma yedeğiyle çakışmaz).
function migrationBackupRaw(veri) {
  try {
    localStorage.setItem(MIGRATION_BACKUP_KEY, JSON.stringify(veri));
    return true;
  } catch (e) {
    return false;
  }
}

function get(id) {
  return state[id] || {};
}

function save() {
  localStorage.setItem(KEY, JSON.stringify(state));
  renderStats();
}

function update(id, field, value) {
  // Kurtarma başarısızsa (tutarsız veri) veri değiştiren işlemleri engelle.
  if (veriKilitli) {
    alert('Veri güvenlik kilidi etkin: önceki içe aktarma kurtarılamadı. Yeni değişiklik yapılamaz. Lütfen sorunu giderin (sayfayı yenileyin veya yedeği geri alın).');
    return;
  }
  state[id] = { ...(state[id] || {}), [field]: value };
  save();
  render();
}

// Riskli işlemlerden önce mevcut veriyi ayrı anahtara yazar.
function backupNow() {
  return backupRaw(state);
}

function hasBackup() {
  return !!localStorage.getItem(BACKUP_KEY);
}

function restoreBackup() {
  const raw = localStorage.getItem(BACKUP_KEY);
  if (!raw) return false;
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    return false;
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return false;

  // Geri alınan veri eski şema olabilir; meta'yı sıfırla ki migration yeniden değerlendirilsin.
  const eskiMeta = localStorage.getItem(SEMA_META_KEY);
  try {
    localStorage.removeItem(SEMA_META_KEY);
    localStorage.setItem(KEY, JSON.stringify(parsed));
  } catch (e) {
    try {
      if (eskiMeta !== null) localStorage.setItem(SEMA_META_KEY, eskiMeta);
    } catch (e2) { /* yok say */ }
    return false;
  }

  loadState();
  render();
  return true;
}

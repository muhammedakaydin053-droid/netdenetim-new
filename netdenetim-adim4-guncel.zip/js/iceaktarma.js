// JSON içe aktarma güvenliği: doğrulama, önizleme, uygulama.
// Bu modül DOM kullanmaz; test edilebilir saf fonksiyonlar içerir.
// Yedek biçimi: v1 {version:1, exportedAt, catalog, ratingsAndPreferences}
//               v2 {version:2, exportedAt, catalog, ratingsAndPreferences, uygunluk}
// v1 yedekleri geriye dönük uyumludur; uygunluk alanı yoksa mevcut düzeltmeler SİLİNMEZ.

const DESTEKLENEN_SURUM = 2;

// İçe aktarmada kabul edilen kullanıcı alanları (mevcut şemayla aynı).
const ALAN_KURALLARI = {
  watched: (v) => typeof v === 'boolean',
  favorite: (v) => typeof v === 'boolean',
  rating: (v) => Number.isInteger(v) && v >= 1 && v <= 10,
  rank: (v) => Number.isInteger(v) && v >= 1,
};

// uygunluk.js'teki doğrulayıcı: tarayıcıda global, Node'da require ile bağlanır.
if (typeof module !== 'undefined' && module.exports) {
  var kayitDogrula = require('./uygunluk.js').kayitDogrula;
}

// Bir kayıttan yalnızca geçerli alanları süzer; geçersiz alanları raporlar.
function kaydiTemizle(id, kayit) {
  const temiz = {};
  const gecersiz = [];
  for (const [alan, deger] of Object.entries(kayit)) {
    const kural = ALAN_KURALLARI[alan];
    if (!kural) continue; // bilinmeyen alan: yok say (ileri uyumluluk için veri değişmez)
    if (kural(deger)) {
      temiz[alan] = deger;
    } else {
      gecersiz.push({ id, field: alan, value: deger });
    }
  }
  return { temiz, gecersiz };
}

// Dosya nesnesini doğrular ve karşılaştırma analizi üretir.
// Dönen: { ok, error, version, exportedAt, fileTotal, valid, unknownIds,
//          invalidValues, currentCount, conflicts, newIds }
function analizEt(obj, katalog, mevcutState) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) {
    return { ok: false, error: 'Dosya bir JSON nesnesi değil.' };
  }
  if (obj.ratingsAndPreferences === undefined) {
    return { ok: false, error: 'Dosyada "ratingsAndPreferences" alanı yok. Bu geçerli bir arşiv yedeği değil.' };
  }
  if (typeof obj.ratingsAndPreferences !== 'object' || obj.ratingsAndPreferences === null || Array.isArray(obj.ratingsAndPreferences)) {
    return { ok: false, error: '"ratingsAndPreferences" bir nesne değil.' };
  }

  const surum = obj.version === undefined ? 1 : obj.version;
  if (!Number.isInteger(surum) || surum < 1) {
    return { ok: false, error: 'Geçersiz yedek sürümü.' };
  }
  if (surum > DESTEKLENEN_SURUM) {
    return { ok: false, error: 'Desteklenmeyen yedek sürümü (' + surum + '). Bu sürüm en fazla ' + DESTEKLENEN_SURUM + ' destekler.' };
  }

  const gecerliIds = new Set(katalog.map((x) => x.id));
  const valid = {};
  const unknownIds = [];
  const invalidValues = [];

  for (const [id, kayit] of Object.entries(obj.ratingsAndPreferences)) {
    if (!kayit || typeof kayit !== 'object' || Array.isArray(kayit)) {
      invalidValues.push({ id, field: '(kayıt)', value: kayit, reason: 'kayıt nesne değil' });
      continue;
    }
    if (!gecerliIds.has(id)) {
      unknownIds.push(id);
      continue;
    }
    const { temiz, gecersiz } = kaydiTemizle(id, kayit);
    if (gecersiz.length) {
      for (const g of gecersiz) invalidValues.push({ ...g, reason: 'geçersiz değer' });
    }
    if (Object.keys(temiz).length) valid[id] = temiz;
  }

  const currentCount = Object.keys(mevcutState).length;
  const conflicts = [];
  const newIds = [];
  for (const [id, dosyaKayit] of Object.entries(valid)) {
    const mevcut = mevcutState[id];
    if (!mevcut) {
      newIds.push(id);
      continue;
    }
    const farkli = Object.keys(dosyaKayit).some((k) => JSON.stringify(mevcut[k]) !== JSON.stringify(dosyaKayit[k]));
    if (farkli) conflicts.push({ id, current: { ...mevcut }, file: { ...dosyaKayit } });
  }

  // Uygunluk katmanı: yalnızca v2+ yedeklerde bulunur. v1 yedeğinde YOKTUR ve
  // mevcut kullanıcı düzeltmelerini SİLMEZ (uygunluk = null → dokunulmaz).
  let uygunluk = null;
  let uygunlukGecerli = {};
  const uygunlukSorunlari = [];
  if (obj.uygunluk !== undefined) {
    if (!obj.uygunluk || typeof obj.uygunluk !== 'object' || Array.isArray(obj.uygunluk)) {
      return { ok: false, error: '"uygunluk" alanı nesne değil. Hiçbir veri değiştirilmedi.' };
    }
    uygunluk = obj.uygunluk;
    for (const [id, kayit] of Object.entries(uygunluk)) {
      if (!gecerliIds.has(id)) { uygunlukSorunlari.push({ id, reason: 'bilinmeyen ID (katalogda yok)' }); continue; }
      const d = kayitDogrula(kayit);
      if (!d.ok) { uygunlukSorunlari.push({ id, reason: 'geçersiz uygunluk kaydı: ' + d.hatalar.map((h) => h.field + ' (' + h.reason + ')').join(', ') }); continue; }
      uygunlukGecerli[id] = kayit;
    }
    // Bozuk/uyumsuz uygunluk verisi içe aktarmayı güvenli biçimde durdurur.
    if (uygunlukSorunlari.length) {
      return { ok: false, error: 'Uygunluk verisi geçersiz: ' + uygunlukSorunlari.map((s) => s.id + ' → ' + s.reason).join('; ') + '. Hiçbir veri değiştirilmedi.' };
    }
  }

  return {
    ok: true,
    version: surum,
    exportedAt: obj.exportedAt || null,
    fileTotal: Object.keys(obj.ratingsAndPreferences).length,
    valid,
    unknownIds,
    invalidValues,
    currentCount,
    conflicts,
    newIds,
    uygunluk,          // ham (v2 ise nesne, v1 ise null)
    uygunlukGecerli,   // doğrulanmış uygunluk kayıtları
    uygunlukVar: uygunluk !== null,
    uygunlukSayisi: uygunluk !== null ? Object.keys(uygunluk).length : 0,
  };
}

// Uygunluk katmanı için yeni durumu hesaplar. Mevcut durumu değiştirmez.
// v1 yedeği (uygunluk yok) → mevcut düzeltmeler KORUNUR (mod ne olursa olsun).
// v2 yedeği: birlestir → üzerine yaz; degistir → yalnızca dosyadaki uygunluk kalır.
function hesaplaYeniUygunlukDurum(mode, analiz, mevcutUygunluk) {
  const mevcut = mevcutUygunluk && typeof mevcutUygunluk === 'object' ? mevcutUygunluk : {};
  if (!analiz.uygunlukVar) {
    // v1 yedeği: uygunluk verisi taşımaz → mevcut düzeltmeler korunur.
    return { ...mevcut };
  }
  if (mode === 'birlestir') {
    return { ...mevcut, ...analiz.uygunlukGecerli };
  }
  return { ...analiz.uygunlukGecerli };
}

// Verilen moda göre yeni durumu hesaplar. Mevcut durumu değiştirmez.
function hesaplaYeniDurum(mode, analiz, mevcutState) {
  const yeni = {};
  if (mode === 'birlestir') {
    // Mevcut kayıtlar korunur; dosyadaki geçerli alanlar üzerine yazılır.
    for (const [id, kayit] of Object.entries(mevcutState)) yeni[id] = { ...kayit };
    for (const [id, kayit] of Object.entries(analiz.valid)) yeni[id] = { ...(yeni[id] || {}), ...kayit };
  } else {
    // Değiştir: yalnızca dosyadaki geçerli kayıtlar kalır.
    for (const [id, kayit] of Object.entries(analiz.valid)) yeni[id] = { ...kayit };
  }
  return yeni;
}

// İşlem sonucu raporu üretir.
function raporOlustur(mode, analiz, mevcutState, yeniDurum) {
  const mevcutIds = Object.keys(mevcutState);
  const validIds = Object.keys(analiz.valid);
  let korunan;
  if (mode === 'birlestir') {
    korunan = mevcutIds.filter((id) => !(id in analiz.valid)).length;
  } else {
    korunan = 0;
  }
  const atilan = analiz.unknownIds.length + analiz.invalidValues.length;
  return {
    mode,
    aktarilan: validIds.length,
    korunan,
    atilan,
    yeniKayit: analiz.newIds.length,
    cakisanKayit: analiz.conflicts.length,
    bilinmeyenId: analiz.unknownIds.length,
    gecersizDeger: analiz.invalidValues.length,
    sonucKayitSayisi: Object.keys(yeniDurum).length,
    uygunlukVar: !!analiz.uygunlukVar,
    uygunlukSayisi: analiz.uygunlukSayisi || 0,
    uygunlukAktarilan: analiz.uygunlukVar ? Object.keys(analiz.uygunlukGecerli).length : 0,
    uygunlukKorunan: analiz.uygunlukVar ? 0 : 'mevcut korunur',
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { analizEt, hesaplaYeniDurum, hesaplaYeniUygunlukDurum, raporOlustur, DESTEKLENEN_SURUM, ALAN_KURALLARI };
}

# Proje Durumu — Kişisel Film ve Dizi Arşivi

Bu dosya, her aşamada güncellenen proje günlüğüdür.

## Proje kimliği

- Proje: Kişisel Film ve Dizi Arşivi (tek kullanıcılı, yerel, çevrimdışı)
- Kaynak dosya: `kisisel_film_dizi_arsivi_guncel (1).html`
- NetDefter projesinden tamamen ayrıdır. Ortak dosya veya git remote yoktur.

## Korunacak değişmezler (kilitli)

| Öğe | Değer |
|-----|-------|
| Kayıt sayısı | 517 (339 film + 178 dizi) |
| En büyük film ID | F-339 |
| En büyük dizi ID | D-178 |
| ID boşluğu | Yok |
| LocalStorage anahtarı | `personal-film-series-archive-v1` |
| Kullanıcı alanları | `watched`, `favorite`, `rating`, `rank` |
| Yedek formatı | `{version, exportedAt, catalog, ratingsAndPreferences}` |
| Orijinal dosya sha256 | `82e0fe4102b92e4e2bc11c9b71351eba601ed000eebd5fb7e5f04b8a39a08163` |

Bu değerler her aşamada `araclar/dogrula_katalog.py` ile kontrol edilir.

## Kullanıcı verisi hakkında not

- Gerçek tarayıcıdaki LocalStorage verisi **görülmedi ve yedeklenmedi**.
- Kullanıcı siteyi henüz kullanmamış; kişisel izleme verisi **yok**.
- Korunması gereken asıl varlık: 517 kayıtlı katalog, ID'ler ve uygulama kodu.
- Veri güvenliği sistemi yine kurulacak (ileride kullanım için).

## Aşama günlüğü

### Aşama 0 — Hazırlık ve yedekleme (TAMAMLANDI)

Yapılanlar:
- Orijinal HTML dosyasının zaman damgalı ve kalıcı yedeği alındı (`yedekler/`).
- Yedeklerin sha256 değeri orijinalle eşleşiyor.
- `.gitignore` oluşturuldu; yedekler ve geçici dosyalar hariç tutuldu.
- Git deposu hazırlandı: branch `main`, **remote yok** (NetDefter'den ayrı).
- Katalog bütünlük doğrulama aracı yazıldı: `araclar/dogrula_katalog.py`.
- Doğrulama çalıştırıldı: **tüm kontroller geçti**.

Değişen/eklenen dosyalar:
- `.gitignore` (yeni)
- `araclar/dogrula_katalog.py` (yeni)
- `DURUM.md` (bu dosya, yeni)
- `yedekler/…` (yeni, git dışı)

Değişmeyen dosyalar:
- `kisisel_film_dizi_arsivi_guncel (1).html` — **hiç dokunulmadı**, sha256 aynı.

Sonraki aşama: Aşama 1 (aşağıda).

### Aşama 1 — JSON içe aktarma güvenliği (TAMAMLANDI)

Çok dosyalı yapıya geçildi (onaylanan mimari, klasik script — çevrimdışı çalışır):

- `index.html` — yapı + modaller
- `css/stil.css` — mevcut CSS + modal stilleri
- `js/veri.js` — katalog (517 kayıt, **birebir korundu**, aynı sha256)
- `js/durum.js` — LocalStorage, otomatik yedek, geri al
- `js/iceaktarma.js` — doğrulama/önizleme/uygulama (DOM'suz, test edilebilir)
- `js/arayuz.js` — listeleme, filtre, sıralama, JSON/CSV dışa aktarma (mevcut davranış korundu)
- `js/uygulama.js` — başlatma + içe aktarma akışı

İçe aktarma akışı (eski bozuk akış değiştirildi):
1. Dosya seç → JSON ayrıştır (bozuksa reddet, veri değişmez)
2. Doğrula: yapı + sürüm (yalnızca v1 desteklenir)
3. Önizleme: mevcut/dosya karşılaştırması, yeni/çakışan/bilinmeyen/geçersiz sayıları
4. Kullanıcı onayı: **Birleştir** veya **Değiştir**
5. Otomatik yedek (`...__backup`), sonra atomik yazma
6. Rapor: aktarılan / korunan / atlanan / yeni / çakışan

Korunan değişmezler: anahtar `personal-film-series-archive-v1`, alanlar
`watched/favorite/rating/rank`, dışa aktarma biçimi, tüm ID'ler.

Eklenen araçlar:
- `araclar/dogrula_katalog.py` (mevcut)
- `testler/` — 4 test dosyası (toplam 80 test)
- `package.json` — yalnızca test bağımlılığı (puppeteer-core)

Test sonuçları: 37 birim + 34 tarayıcı + 7 çevrimdışı + 2 atomiklik = **80/80 geçti**.

Sonraki aşama: Aşama 2 (aşağıda).

### Aşama 2 — Sürümlü veri modeli ve migration altyapısı (TAMAMLANDI)

Amaç: yeni özellik değil, mevcut verinin gelecekte güvenle genişletilebilmesi.

Tasarım kararı (önemli): Kullanıcı kaydının şekli `watched/favorite/rating/rank`
olarak **korundu**. Sürüm bilgisi ayrı meta anahtarına yazılır. Nedeni: Aşama 1'in
107 testi state şekline bağlı; şekli değiştirmek onları kırardı ve şart "mevcut
testler çalışmaya devam etmeli" idi. Ayrıca eski veriler ve dışa/içe aktarma
biçimi hiç bozulmadı.

- `js/sema.js` (yeni, saf): `durumTuret`, `kayitIncele`, `migrationPlanla`,
  `GUNCEL_SEMA=2`, `SEMA_META_KEY`, `MIGRATION_BACKUP_KEY`
- `js/durum.js`: `loadState` artık migration yapar (yedek → atomik meta yazımı →
  hata/ileri sürüm/bozuk durumda veriyi korur); `restoreBackup` meta'yı sıfırlar
- `js/uygulama.js`: `baslat()` migration sonucunu bildirir
- `index.html`: `sema.js` yüklenir

Şema sürümü: `_schema: 2` (ayrı anahtar: `personal-film-series-archive-v1__meta`).
Migration yedeği ayrı anahtar: `...__migration-backup` (içe aktarma yedeğini ezmez).
İzleme durumu `watched`'tan **türetilir** (`izlendi`/`izlenmedi`/`izlenecek`);
state'e yazılmaz, izleme tarihi **uydurulmaz**, `watchLog` oluşturulmaz.

Korunan değişmezler: anahtar `personal-film-series-archive-v1`, alanlar
`watched/favorite/rating/rank`, dışa/içe aktarma biçimi, tüm ID'ler, 517 katalog.

Yeni testler: `testler/sema.test.js` (36), `testler/migrasyon_tarayici.test.js` (44).

Test sonuçları: 37+36+34+44+7+2+27 = **187/187 geçti** (mevcut 107 korundu).

Sonraki aşama (onay bekliyor): — kullanıcı kararına bağlı.

// Aşama 1 uçtan uca tarayıcı testleri (gerçek Chromium motoru, headless).
// Çalıştırma: node testler/tarayici.test.js
// Ön koşul: http://localhost:12000 üzerinde yerel sunucu çalışıyor olmalı.
const puppeteer = require('puppeteer-core');

const EXEC = '/usr/bin/chromium';
const URL = 'http://localhost:12000/index.html';
const BACKUP_KEY = 'personal-film-series-archive-v1__backup';

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}

async function lsState(page) {
  return page.evaluate(() => JSON.parse(localStorage.getItem('personal-film-series-archive-v1') || '{}'));
}

async function dosyaSec(page, metin) {
  await page.evaluate((m) => {
    const file = new File([m], 'yedek.json', { type: 'application/json' });
    const dt = new DataTransfer();
    dt.items.add(file);
    const input = document.getElementById('file');
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }, metin);
}

async function yedekYukle(page, obj) {
  await dosyaSec(page, JSON.stringify(obj));
  await page.waitForFunction(() => !document.getElementById('iceModal').classList.contains('hidden'), { timeout: 5000 });
}

async function yedekYukleReddet(page, obj) {
  await dosyaSec(page, JSON.stringify(obj));
  await new Promise((r) => setTimeout(r, 400));
  const acik = await page.$eval('#iceModal', (e) => !e.classList.contains('hidden'));
  esit('Reddedilen dosya için pencere açılmadı', acik, false);
}

(async () => {
  const browser = await puppeteer.launch({ executablePath: EXEC, headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();

  const hatalar = [];
  page.on('pageerror', (e) => hatalar.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') hatalar.push('console.error: ' + m.text()); });

  const alerts = [];
  page.on('dialog', async (d) => { alerts.push({ type: d.type(), message: d.message() }); await d.accept(); });

  console.log('== A) Sayfa yükleniyor ==');
  await page.goto(URL, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });

  esit('Toplam yapım = 517', await page.$eval('#total', (e) => e.textContent), '517');
  esit('Listede 517 kart', await page.$$eval('#list .item', (els) => els.length), 517);
  esit('Sayfa hatası yok', hatalar, []);

  console.log('\n== B) Mevcut özellikler çalışıyor mu (geriye dönük) ==');
  // Çoklu tür paneli: tek tür seçimi (OR grubu).
  await page.click('#turBtn');
  await page.evaluate(() => {
    const cb = [...document.querySelectorAll('#turPanel input[type="checkbox"]')].find((c) => c.value === 'Bilim kurgu');
    cb.checked = true;
    cb.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length > 0);
  esit('Bilim kurgu filtresi = 85', await page.$$eval('#list .item', (els) => els.length), 85);
  await page.click('#reset');
  esit('Filtre temizle → 517', await page.$$eval('#list .item', (els) => els.length), 517);

  await page.type('#q', 'Godfather');
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length < 10);
  esit('Arama "Godfather" = 2', await page.$$eval('#list .item', (els) => els.length), 2);
  await page.click('#reset');

  // A–Z sırasında listenin ilk öğesi F-226 (12 Angry Men). O kartı puanla.
  await page.evaluate(() => { const r = document.querySelector('#list .item .rating'); r.value = '9'; r.dispatchEvent(new Event('change', { bubbles: true })); });
  esit('Puan verilince "Puanladıklarım" = 1', await page.$eval('#rated', (e) => e.textContent), '1');
  const s1 = await lsState(page);
  esit('İlk kart (F-226) rating yazıldı (9)', s1['F-226'] && s1['F-226'].rating, 9);

  console.log('\n== C) Bozuk dosya reddi (veri değişmemeli) ==');
  const oncekiState = JSON.stringify(await lsState(page));
  await dosyaSec(page, '{ bu json degil');
  await new Promise((r) => setTimeout(r, 400));
  esit('Geçersiz JSON sonrası veri değişmedi', JSON.stringify(await lsState(page)), oncekiState);
  esit('Geçersiz JSON uyarısı gösterildi', alerts.some((a) => a.message.includes('geçerli bir JSON')), true);

  await yedekYukleReddet(page, { version: 1, foo: 'bar' });
  esit('ratingsAndPreferences eksik → veri değişmedi', JSON.stringify(await lsState(page)), oncekiState);

  await yedekYukleReddet(page, { version: 99, ratingsAndPreferences: { 'F-001': { rating: 5 } } });
  esit('Sürüm 99 → veri değişmedi', JSON.stringify(await lsState(page)), oncekiState);

  console.log('\n== D) Geçerli dosya: önizleme + Değiştir ==');
  const dosya = {
    version: 1, exportedAt: '2025-06-01T00:00:00.000Z',
    ratingsAndPreferences: {
      'F-001': { watched: true, rating: 10, favorite: true, rank: 1 },
      'F-002': { watched: false, rating: 7 },
      'F-999': { watched: true },
      'D-001': { rating: 0 },
    },
  };
  await yedekYukle(page, dosya);
  const ozet = await page.$eval('#iceOzet', (e) => e.textContent);
  esit('Önizleme bilinmeyen ID=1', ozet.includes('Bilinmeyen ID (katalogda yok): 1'), true);
  esit('Önizleme geçersiz değer=1', ozet.includes('Geçersiz değer: 1'), true);
  esit('Önizleme aktarılabilir=2', ozet.includes('Aktarılabilir geçerli kayıt: 2'), true);

  await page.click('#iceDegistir');
  await new Promise((r) => setTimeout(r, 400));
  const sDegistir = await lsState(page);
  esit('Değiştir: yalnızca 2 geçerli kayıt', Object.keys(sDegistir).sort(), ['F-001', 'F-002']);
  esit('F-001 değerleri dosyadan', sDegistir['F-001'], { watched: true, rating: 10, favorite: true, rank: 1 });
  esit('Bilinmeyen F-999 eklenmedi', sDegistir['F-999'], undefined);
  const raporMesaj = alerts.map((a) => a.message).join('\n');
  esit('Rapor: aktarılan 2', raporMesaj.includes('Aktarılan kayıt: 2'), true);
  esit('Rapor: atlanan 2', raporMesaj.includes('Atlanan kayıt: 2'), true);
  esit('Otomatik yedek alındı', await page.evaluate((k) => !!localStorage.getItem(k), BACKUP_KEY), true);

  console.log('\n== E) Birleştir modu: mevcut korunur ==');
  const dosya2 = { version: 1, ratingsAndPreferences: { 'F-002': { rating: 3 }, 'F-003': { favorite: true } } };
  await yedekYukle(page, dosya2);
  await page.click('#iceBirlestir');
  await new Promise((r) => setTimeout(r, 400));
  const sBirlestir = await lsState(page);
  esit('Birleştir: F-001 korundu', !!sBirlestir['F-001'], true);
  // F-002 dosyada yalnızca rating içeriyor; mevcut "watched" alanı korunur (alan düzeyi birleştirme).
  esit('Birleştir: F-002 rating güncellendi', sBirlestir['F-002'].rating, 3);
  esit('Birleştir: F-002 watched korundu', sBirlestir['F-002'].watched, false);
  esit('Birleştir: F-003 eklendi', sBirlestir['F-003'], { favorite: true });
  esit('Birleştir: toplam 3 kayıt', Object.keys(sBirlestir).length, 3);

  console.log('\n== F) Geri al ==');
  await page.click('#geriAl');
  await new Promise((r) => setTimeout(r, 200));
  esit('Geri al penceresi açıldı', await page.$eval('#geriAlModal', (e) => !e.classList.contains('hidden')), true);
  await page.click('#geriAlOnay');
  await new Promise((r) => setTimeout(r, 300));
  esit('Geri al: birleştirme öncesi durum (2 kayıt)', Object.keys(await lsState(page)).sort(), ['F-001', 'F-002']);

  console.log('\n== G) Katalog ve ID korundu mu ==');
  esit('Katalog hâlâ 517', await page.evaluate(() => catalog.length), 517);
  esit('İlk ID F-001', await page.evaluate(() => catalog[0].id), 'F-001');
  esit('Son ID D-178', await page.evaluate(() => catalog[catalog.length - 1].id), 'D-178');

  esit('Sayfa hatası yok (tüm test boyunca)', hatalar, []);

  await browser.close();
  console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
  if (hatalar.length) console.log('HATALAR:', hatalar);
  process.exit(kalan ? 1 : 0);
})();

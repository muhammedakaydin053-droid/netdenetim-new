// Aşama 3.3 — Katalog sınıflandırma tutarlılığı testi.
// js/veri.js'teki 517 kaydın turler/altTurler/etiketler/ozellik alanlarını
// js/turler.js doğrulayıcısıyla kontrol eder. Kataloğu DEĞİŞTİRMEZ.
// Çalıştırma: node testler/katalog_turler.test.js
const fs = require('fs');
const path = require('path');
const T = require('../js/turler.js');

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}
function dogru(ad, kosul) { esit(ad, !!kosul, true); }

const veriSrc = fs.readFileSync(path.join(__dirname, '..', 'js', 'veri.js'), 'utf8');
const catalog = eval('(' + veriSrc.replace(/^const catalog=/, '').replace(/;\s*$/, '') + ')');

console.log('== Temel bütünlük ==');
esit('517 kayıt', catalog.length, 517);
esit('ilk ID F-001', catalog[0].id, 'F-001');
esit('son ID D-178', catalog[catalog.length - 1].id, 'D-178');
esit('tekil ID', new Set(catalog.map((x) => x.id)).size, 517);
dogru('her kayıtta id/title/kind/genre korunmuş',
  catalog.every((x) => x.id && x.title && x.kind && x.genre));

console.log('\n== Zorunlu alanlar ve doğrulama ==');
esit('her kayıtta turler dizisi', catalog.every((x) => Array.isArray(x.turler)), true);
const hatali = catalog.filter((x) => !T.kayitDogrula(x).ok);
esit('tüm kayıtlar kayitDogrula ok', hatali.map((x) => x.id), []);

console.log('\n== Ana tür dağılımı ==');
const anaCnt = {};
for (const r of catalog) for (const t of r.turler) anaCnt[t] = (anaCnt[t] || 0) + 1;
esit('toplam ana tür ataması 1259', Object.values(anaCnt).reduce((a, b) => a + b, 0), 1259);
esit('19 ana tür kullanımda', Object.keys(anaCnt).length, 19);
esit('Dram = 320', anaCnt['Dram'], 320);
esit('Gerilim = 138', anaCnt['Gerilim'], 138);
esit('Suç = 91', anaCnt['Suç'], 91);
esit('Komedi = 90', anaCnt['Komedi'], 90);
esit('Bilim kurgu = 85', anaCnt['Bilim kurgu'], 85);
esit('Savaş = 33', anaCnt['Savaş'], 33);
esit('Tarih = 37', anaCnt['Tarih'], 37);
esit('Spor = 11', anaCnt['Spor'], 11);

console.log('\n== Kayıt dağılımı ==');
esit('çoklu (2+) tür', catalog.filter((x) => x.turler.length >= 2).length, 470);
esit('tek tür', catalog.filter((x) => x.turler.length === 1).length, 43);
esit('boş tür', catalog.filter((x) => x.turler.length === 0).length, 4);
esit('4+ tür', catalog.filter((x) => x.turler.length >= 4).map((x) => x.id).sort(), ['F-062', 'F-073', 'F-253']);

console.log('\n== Alt tür (kayıt / atama) ==');
const altKayit = catalog.filter((x) => Array.isArray(x.altTurler) && x.altTurler.length).length;
const altAtama = catalog.reduce((a, x) => a + ((x.altTurler || []).length), 0);
esit('alt tür kayıt sayısı 78', altKayit, 78);
esit('alt tür atama sayısı 90', altAtama, 90);
const altCnt = {};
for (const r of catalog) for (const a of (r.altTurler || [])) altCnt[a] = (altCnt[a] || 0) + 1;
esit('Psikolojik = 22', altCnt['Psikolojik'], 22);
esit('Dedektif = 20', altCnt['Dedektif'], 20);
esit('Hayatta kalma = 16', altCnt['Hayatta kalma'], 16);
esit('Casusluk = 12', altCnt['Casusluk'], 12);
esit('Polisiye = 11', altCnt['Polisiye'], 11);
esit('Gangster = 9', altCnt['Gangster'], 9);

console.log('\n== Etiket (kayıt / atama) ==');
const etKayit = catalog.filter((x) => Array.isArray(x.etiketler) && x.etiketler.length).length;
const etAtama = catalog.reduce((a, x) => a + ((x.etiketler || []).length), 0);
esit('etiket kayıt sayısı 69', etKayit, 69);
esit('etiket atama sayısı 76', etAtama, 76);
esit('Karakter odaklı kullanımı 0', catalog.filter((x) => (x.etiketler || []).includes('Karakter odaklı')).length, 0);

console.log('\n== Özellikler ==');
esit('ortam=Animasyon 49', catalog.filter((x) => x.ortam === 'Animasyon').length, 49);
esit('animasyonGelenegi=Anime 26', catalog.filter((x) => x.animasyonGelenegi === 'Anime').length, 26);
esit('animasyonGelenegi=Batı 23', catalog.filter((x) => x.animasyonGelenegi === 'Batı').length, 23);
esit('bicim=Mini dizi 9', catalog.filter((x) => x.bicim === 'Mini dizi').length, 9);
dogru('her animasyonGelenegi kaydı ortam=Animasyon',
  catalog.filter((x) => x.animasyonGelenegi).every((x) => x.ortam === 'Animasyon'));

console.log('\n== İnceleme bekleyen 4 kayıt ==');
for (const id of ['F-186', 'F-190', 'F-314', 'F-315']) {
  const r = catalog.find((x) => x.id === id);
  esit(id + ' turler boş', r.turler, []);
  esit(id + ' gozdenGecir true', r.gozdenGecir, true);
}

console.log('\n== Onaylı özel kararlar ==');
const q = catalog.find((x) => x.id === 'D-088');
esit("D-088 Queen's Gambit Dram+Spor", q.turler, ['Dram', 'Spor']);
esit('F-254 Dram+Felaket', catalog.find((x) => x.id === 'F-254').turler, ['Dram', 'Felaket']);
esit('F-254 alt Hayatta kalma', catalog.find((x) => x.id === 'F-254').altTurler, ['Hayatta kalma']);
esit('F-250 Biyografi var', catalog.find((x) => x.id === 'F-250').turler.includes('Biyografi'), true);
esit('D-005 Polisiye yok', (catalog.find((x) => x.id === 'D-005').altTurler || []).includes('Polisiye'), false);
esit('F-020 Polisiye yok', (catalog.find((x) => x.id === 'F-020').altTurler || []).includes('Polisiye'), false);
esit('F-020 Psikolojik+Dedektif', catalog.find((x) => x.id === 'F-020').altTurler, ['Psikolojik', 'Dedektif']);
const dunya = catalog.filter((x) => (x.etiketler || []).includes('Dünya sineması')).map((x) => x.id).sort();
esit('Dünya sineması yalnızca 5 kayıt', dunya, ['F-311', 'F-314', 'F-315', 'F-317', 'F-325']);

console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
process.exit(kalan ? 1 : 0);

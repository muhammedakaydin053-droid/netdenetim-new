// Aşama 3.4 Adım 4 — İçerik uygunluğu uçtan uca (tarayıcı) testleri.
// Ön koşul: http://localhost:12000 sunucusu. Çalıştırma: node testler/uygunluk_tarayici.test.js
const puppeteer = require('puppeteer-core');
const path = require('path');

const EXEC = '/usr/bin/chromium';
const URL = 'http://localhost:12000/index.html';
const FILE_URL = 'file://' + path.resolve(__dirname, '..', 'index.html');
const KEY = 'personal-film-series-archive-v1';
const UY_KEY = KEY + '__uygunluk';
const UY_BACKUP = KEY + '__uygunluk-backup';

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}
function dogru(ad, kosul) { esit(ad, !!kosul, true); }

// Yedek dosyasını dosya girişine yükler ve önizlemenin açılmasını bekler.
async function yedekYukle(page, obj) {
  await page.evaluate((o) => {
    const file = new File([JSON.stringify(o)], 'yedek.json', { type: 'application/json' });
    const dt = new DataTransfer(); dt.items.add(file);
    const input = document.getElementById('file');
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }, obj);
  await page.waitForFunction(() => !document.getElementById('iceModal').classList.contains('hidden'), { timeout: 5000 });
}

// Yedek yükler ama önizleme açılmasa da devam eder (red senaryoları için).
async function yedekDene(page, obj) {
  await page.evaluate(() => document.getElementById('iceModal').classList.add('hidden'));
  await page.evaluate((o) => {
    const file = new File([JSON.stringify(o)], 'yedek.json', { type: 'application/json' });
    const dt = new DataTransfer(); dt.items.add(file);
    const input = document.getElementById('file');
    input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }, obj);
  await new Promise((r) => setTimeout(r, 400));
}

(async () => {
  const browser = await puppeteer.launch({ executablePath: EXEC, headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const hatalar = [], alerts = [];
  page.on('pageerror', (e) => hatalar.push('pageerror: ' + e.message));
  page.on('dialog', async (d) => { alerts.push(d.message()); await d.accept(); });

  await page.goto(URL, { waitUntil: 'networkidle0' });

  // ============================================================
  console.log('== A) Başlangıç: 517 kayıt, uygunluk katmanı temiz ==');
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });
  esit('katalog 517', await page.evaluate(() => catalog.length), 517);
  esit('uygunluk anahtarı boş', await page.evaluate((k) => localStorage.getItem(k), UY_KEY), null);
  esit('UYGUNLUK_TEMEL boş', await page.evaluate(() => Object.keys(UYGUNLUK_TEMEL).length), 0);
  const ozet0 = await page.evaluate(() => durumOzeti(catalog, UYGUNLUK_TEMEL, getUygunlukRaw()));
  esit('517 incelenmemiş', ozet0.incelenmemis, 517);

  // ============================================================
  console.log('\n== B) Kullanıcı düzeltmesi ayrı anahtara yazılır ==');
  const b = await page.evaluate((k) => {
    uygunlukDuzelt('F-001', 'kategori', { kategori: 'siddet', seviye: 'orta' });
    uygunlukDuzelt('F-001', 'kategori', { kategori: 'madde', seviye: 'yok' });
    return { ham: localStorage.getItem(k), gecerli: uygunlukGet('F-001') };
  }, UY_KEY);
  dogru('ayrı anahtar dolduruldu', b.ham !== null);
  esit('geçerli kategoriler', b.gecerli.gecerli.kategoriler, { siddet: 'orta', madde: 'yok' });
  esit('geçerli sonuç', b.gecerli.gecerli.sonuc, 'uyari-ile');
  esit('ana kullanıcı anahtarı boş kaldı', await page.evaluate((k) => localStorage.getItem(k), KEY), null);

  // ============================================================
  console.log('\n== C) JSON v2 dışa aktarma uygunluğu içerir ==');
  const json = await page.evaluate(() => {
    window.__json = null; window.download = (n, c) => { window.__json = { n, c }; };
    disaAktarJSON();
    return JSON.parse(window.__json.c);
  });
  esit('version 2', json.version, 2);
  esit('catalog 517', json.catalog.length, 517);
  dogru('uygunluk alanı var', !!json.uygunluk);
  esit('uygunluk F-001 taşındı', json.uygunluk['F-001'].kategoriler.siddet, 'orta');

  // ============================================================
  console.log('\n== D) v2 yedeğini geri yükle (Değiştir) ==');
  await page.evaluate(() => { uygunlukDuzelt('F-001', 'kategori', { kategori: 'siddet', seviye: 'yogun' }); });
  await yedekYukle(page, json); // dosyadaki siddet=orta
  await page.click('#iceDegistir');
  await new Promise((r) => setTimeout(r, 400));
  const dSonrasi = await page.evaluate(() => uygunlukGet('F-001').gecerli.kategoriler.siddet);
  esit('v2 Değiştir dosyadaki değeri uyguladı', dSonrasi, 'orta');

  // ============================================================
  console.log('\n== E) v1 yedeği mevcut uygunluk düzeltmesini SİLMEZ ==');
  await page.evaluate(() => { localStorage.setItem('personal-film-series-archive-v1__uygunluk', JSON.stringify({ 'F-002': { id: 'F-002', kategoriler: { madde: 'hafif' } } })); loadUygunluk(); });
  const v1 = { version: 1, exportedAt: '2020-01-01T00:00:00.000Z', ratingsAndPreferences: { 'F-003': { rating: 7 } } };
  await yedekYukle(page, v1);
  await page.click('#iceDegistir');
  await new Promise((r) => setTimeout(r, 400));
  const eSonrasi = await page.evaluate((k) => ({ uy: JSON.parse(localStorage.getItem(k) || '{}') }), UY_KEY);
  esit('v1 Değiştir sonrası uygunluk KORUNDU', eSonrasi.uy['F-002'].kategoriler.madde, 'hafif');

  // ============================================================
  console.log('\n== F) Bozuk uygunluk verisi güvenli reddedilir ==');
  const bozuk = { version: 2, ratingsAndPreferences: {}, uygunluk: { 'F-001': { id: 'F-001', kategoriler: { siddet: 'asiri' } } } };
  await yedekDene(page, bozuk);
  const modalAcik = await page.evaluate(() => !document.getElementById('iceModal').classList.contains('hidden'));
  esit('bozuk yedekte önizleme açılmadı', modalAcik, false);
  dogru('red uyarısı gösterildi', alerts.some((m) => m.includes('reddedildi') || m.includes('geçersiz') || m.includes('değiştirilmedi')));
  // çelişkili sonuç da reddedilmeli
  await yedekDene(page, { version: 2, ratingsAndPreferences: {}, uygunluk: { 'F-001': { id: 'F-001', kategoriler: { siddet: 'yogun' }, sonuc: 'birlikte-uygun' } } });
  esit('çelişkili yedekte önizleme açılmadı', await page.evaluate(() => !document.getElementById('iceModal').classList.contains('hidden')), false);

  // ============================================================
  console.log('\n== G) Sezon bazlı değerlendirme ==');
  const sezon = await page.evaluate(() => {
    const d = kayitDogrula({ id: 'D-001', kategoriler: { siddet: 'hafif' }, sezonlar: { 1: { kategoriler: { siddet: 'hafif' }, sonuc: 'uyari-ile' }, 2: { kategoriler: { siddet: 'yogun' }, sonuc: 'uygun-degil' } } });
    return { ok: d.ok, genel: sezonlardanSonuc(d.temiz.sezonlar) };
  });
  dogru('sezonlu kayıt geçerli', sezon.ok);
  esit('dizi geneli en kötü sezon', sezon.genel, 'uygun-degil');

  // ============================================================
  console.log('\n== H) Geri alma: uygunluk katmanı da geri döner ==');
  const h = await page.evaluate((uyKey, uyBk) => {
    localStorage.clear(); uygunlukState = {};
    uygunlukDuzelt('F-010', 'kategori', { kategori: 'siddet', seviye: 'hafif' });
    const onceki = JSON.parse(localStorage.getItem(uyKey));
    uygunlukBackupAl();                                   // içe aktarma öncesi yedek
    uygunlukDuzelt('F-010', 'kategori', { kategori: 'siddet', seviye: 'yogun' }); // değişiklik
    const degismis = JSON.parse(localStorage.getItem(uyKey));
    const ok = uygunlukGeriAl();                          // geri al
    const sonra = JSON.parse(localStorage.getItem(uyKey));
    return { onceki, degismis, ok, sonra, yedekVar: localStorage.getItem(uyBk) !== null };
  }, UY_KEY, UY_BACKUP);
  esit('değişiklik uygulandı', h.degismis['F-010'].kategoriler.siddet, 'yogun');
  dogru('geri alma başarılı', h.ok);
  esit('geri alınca önceki değer', h.sonra['F-010'].kategoriler.siddet, 'hafif');
  dogru('uygunluk yedeği alınmış', h.yedekVar);

  // ============================================================
  console.log('\n== I) Bozuk uygunluk ham verisi silinmez (loadUygunluk) ==');
  const i = await page.evaluate((k) => {
    localStorage.setItem(k, '{bozuk json');
    const r = loadUygunluk();
    const ham = localStorage.getItem(k);
    return { ok: r.ok, ham };
  }, UY_KEY);
  esit('loadUygunluk ok=false', i.ok, false);
  esit('ham bozuk veri silinmedi', i.ham, '{bozuk json');

  // ============================================================
  console.log('\n== J) Mevcut işlevler bozulmadı ==');
  await page.evaluate(() => { localStorage.clear(); });
  await page.reload({ waitUntil: 'networkidle0' });
  esit('kart sayısı 517', await page.$$eval('#list .item', (els) => els.length), 517);
  esit('toplam 517', await page.$eval('#total', (e) => e.textContent), '517');
  await page.evaluate(() => { const r = document.querySelector('#list .item .rating'); r.value = '9'; r.dispatchEvent(new Event('change', { bubbles: true })); });
  esit('puanlama çalışıyor', await page.$eval('#rated', (e) => e.textContent), '1');

  // ============================================================
  console.log('\n== K) Çevrimdışı (file://) uygunluk katmanı ==');
  const page2 = await browser.newPage();
  page2.on('dialog', async (d) => { await d.accept(); });
  await page2.goto(FILE_URL, { waitUntil: 'load' });
  const k = await page2.evaluate((uyKey) => {
    localStorage.clear(); uygunlukState = {};
    uygunlukDuzelt('F-001', 'kategori', { kategori: 'siddet', seviye: 'orta' });
    const json = { version: 2, ratingsAndPreferences: {}, uygunluk: JSON.parse(localStorage.getItem(uyKey)) };
    const a = analizEt(json, catalog, {});
    return { ok: a.ok, var: a.uygunlukVar, sonuc: uygunlukGet('F-001').gecerli.sonuc };
  }, UY_KEY);
  dogru('file:// analiz ok', k.ok);
  dogru('file:// uygunlukVar', k.var);
  esit('file:// sonuç türetildi', k.sonuc, 'uyari-ile');

  // ============================================================
  console.log('\n== I2) Denetim bulgusu 1 — düzeltme kaldırma (kaynak değere dönüş) ==');
  const i2 = await page.evaluate(() => {
    localStorage.clear(); uygunlukState = {};
    // Kaynak temel veri ekle (test amaçlı; gerçek UYGUNLUK_TEMEL boş kalır).
    UYGUNLUK_TEMEL['F-100'] = { id: 'F-100', kategoriler: { siddet: 'hafif' } };
    // ÖNCE: kullanıcı düzeltmesi kaynağı geçersiz kılar.
    uygunlukDuzelt('F-100', 'kategori', { kategori: 'siddet', seviye: 'yogun' });
    const onceki = uygunlukGet('F-100');
    // SONRA: düzeltme kaldırılır → kaynak değere dönülür.
    uygunlukDuzeltmeKaldir('F-100', 'siddet');
    const sonraki = uygunlukGet('F-100');
    const kalanHam = localStorage.getItem('personal-film-series-archive-v1__uygunluk');
    delete UYGUNLUK_TEMEL['F-100'];
    return {
      oncekiDeger: onceki.gecerli.kategoriler.siddet,
      oncekiDuzeltme: onceki.duzeltilenAlanlar.slice(),
      sonrakiDeger: sonraki.gecerli.kategoriler.siddet,
      sonrakiDuzeltme: sonraki.duzeltilenAlanlar.slice(),
      sonrakiSonuc: sonraki.gecerli.sonuc,
      kalanHam,
    };
  });
  esit('ÖNCE: kullanıcı değeri yogun', i2.oncekiDeger, 'yogun');
  esit('ÖNCE: duzeltilenAlanlar siddet içerir', i2.oncekiDuzeltme, ['kategoriler.siddet']);
  esit('SONRA: kaynak değere döndü (hafif)', i2.sonrakiDeger, 'hafif');
  esit('SONRA: duzeltilenAlanlar boş', i2.sonrakiDuzeltme, []);
  esit('SONRA: sonuç kaynaktan türetildi', i2.sonrakiSonuc, 'uyari-ile');
  esit('SONRA: kullanıcı kaydı tamamen silindi', i2.kalanHam, null);

  // Düzeltme kaldırma: kısmi kalış (başka alan varsa kayıt korunur)
  const i2b = await page.evaluate(() => {
    localStorage.clear(); uygunlukState = {};
    uygunlukDuzelt('F-101', 'kategori', { kategori: 'siddet', seviye: 'orta' });
    uygunlukDuzelt('F-101', 'kullaniciNotu', 'not');
    uygunlukDuzeltmeKaldir('F-101', 'siddet');
    const b = uygunlukGet('F-101');
    return { duzeltme: b.duzeltilenAlanlar.slice(), kategoriVar: 'siddet' in b.gecerli.kategoriler, not: b.gecerli.kullaniciNotu };
  });
  esit('Kısmi: yalnızca kullaniciNotu düzeltme kaldı', i2b.duzeltme, ['kullaniciNotu']);
  dogru('Kısmi: kategori kaldırıldı', i2b.kategoriVar === false);
  esit('Kısmi: not korundu', i2b.not, 'not');

  // Tam sıfırlama
  const i2c = await page.evaluate(() => {
    uygunlukDuzelt('F-102', 'kategori', { kategori: 'siddet', seviye: 'yogun' });
    const ok = uygunlukSifirla('F-102');
    return { ok, ham: JSON.parse(localStorage.getItem('personal-film-series-archive-v1__uygunluk') || '{}') };
  });
  dogru('Sıfırlama ok döndü', i2c.ok);
  dogru('Sıfırlama sonrası kayıt yok', !('F-102' in i2c.ham));

  // ============================================================
  console.log('\n== I3) Denetim bulgusu 2 — journal atomikliği ve kurtarma ==');
  const i3 = await page.evaluate(() => {
    localStorage.clear(); uygunlukState = {}; state = {};
    // Başarılı yazım: journal temizlenmeli.
    const r1 = ikiAnahtarYaz({ 'F-001': { rating: 5 } }, { 'F-001': { id: 'F-001', kategoriler: { siddet: 'orta' } } });
    const journalSonrasi = localStorage.getItem('personal-film-series-archive-v1__journal');
    // Yarım kalmış işlemi taklit et: journal bırak, kullanıcı anahtarını yeni, uygunluğu eski bırak.
    localStorage.setItem('personal-film-series-archive-v1__journal', JSON.stringify({
      kullanici: { 'F-002': { rating: 9 } }, uygunluk: { 'F-002': { id: 'F-002', kategoriler: { siddet: 'yogun' } } },
      eskiKullanici: JSON.stringify({ 'F-001': { rating: 5 } }),
      eskiUygunluk: JSON.stringify({ 'F-001': { id: 'F-001', kategoriler: { siddet: 'orta' } } }),
      ts: Date.now(),
    }));
    localStorage.setItem('personal-film-series-archive-v1', JSON.stringify({ 'F-002': { rating: 9 } })); // yalnızca kullanıcı yazıldı
    const kurtarma = journalKurtar();
    const kullaniciSonra = JSON.parse(localStorage.getItem('personal-film-series-archive-v1'));
    const uygunlukSonra = JSON.parse(localStorage.getItem('personal-film-series-archive-v1__uygunluk'));
    const journalKaldi = localStorage.getItem('personal-film-series-archive-v1__journal');
    return { r1ok: r1.ok, journalSonrasi, kurtarma, kullaniciSonra, uygunlukSonra, journalKaldi };
  });
  dogru('Başarılı yazım ok', i3.r1ok);
  esit('Başarılı yazımda journal temizlendi', i3.journalSonrasi, null);
  esit('Kurtarma türü geri-alindi', i3.kurtarma.kurtarildi, 'geri-alindi');
  esit('Kurtarma: kullanıcı eski değere döndü', i3.kullaniciSonra['F-001'].rating, 5);
  esit('Kurtarma: uygunluk eski değere döndü', i3.uygunlukSonra['F-001'].kategoriler.siddet, 'orta');
  esit('Kurtarma: journal temizlendi', i3.journalKaldi, null);

  // Tamamlanmış (her iki anahtar yeni) → journal yalnızca temizlenir.
  const i3b = await page.evaluate(() => {
    localStorage.clear();
    const yeni = { kullanici: { 'F-003': { rating: 7 } }, uygunluk: { 'F-003': { id: 'F-003', kategoriler: { madde: 'yok' } } } };
    localStorage.setItem('personal-film-series-archive-v1', JSON.stringify(yeni.kullanici));
    localStorage.setItem('personal-film-series-archive-v1__uygunluk', JSON.stringify(yeni.uygunluk));
    localStorage.setItem('personal-film-series-archive-v1__journal', JSON.stringify({ ...yeni, eskiKullanici: null, eskiUygunluk: null, ts: Date.now() }));
    const r = journalKurtar();
    return { tur: r.kurtarildi, kullanici: JSON.parse(localStorage.getItem('personal-film-series-archive-v1')) };
  });
  esit('Tamamlanmış işlem: kurtarma=tamamlandi', i3b.tur, 'tamamlandi');
  esit('Tamamlanmış işlem: veri korundu', i3b.kullanici['F-003'].rating, 7);

  // Tutarlılık doğrulama yardımcısı
  const i3c = await page.evaluate(() => {
    localStorage.clear();
    localStorage.setItem('personal-film-series-archive-v1', JSON.stringify({ a: 1 }));
    localStorage.setItem('personal-film-series-archive-v1__uygunluk', JSON.stringify({ b: 2 }));
    const tutarli = ikiKatmanTutarliMi({ a: 1 }, { b: 2 });
    const tutarsiz = ikiKatmanTutarliMi({ a: 1 }, { b: 3 });
    return { tutarli: tutarli.tutarli, tutarsiz: tutarsiz.tutarli, neden: tutarsiz.neden };
  });
  dogru('Eşleşen iki katman tutarlı', i3c.tutarli);
  dogru('Farklı uygunluk tutarsız', i3c.tutarsiz === false);
  dogru('Tutarsızlık nedeni bildirildi', i3c.neden.includes('Uygunluk'));

  // ============================================================
  console.log('\n== I4) Denetim bulgusu 4 — bilinmeyen ortam "Canlı aksiyon" DEĞİL ==');
  const i4 = await page.evaluate(() => {
    localStorage.clear();
    const belirtilmemis = catalog.filter((x) => !x.ortam).length;
    const animasyon = catalog.filter((x) => x.ortam === 'Animasyon').length;
    const canli = catalog.filter((x) => x.ortam === 'Canlı aksiyon').length;
    // ozellikGecti: alanı olmayan kayıt "Canlı aksiyon" seçimine girmez.
    const ornekKayit = catalog.find((x) => !x.ortam);
    const canliGecti = ozellikGecti(ornekKayit, 'ortam', ['Canlı aksiyon']);
    const belirsizGecti = ozellikGecti(ornekKayit, 'ortam', ['Belirtilmemiş']);
    return { belirtilmemis, animasyon, canli, canliGecti, belirsizGecti, sentinel: ORTAM_BELIRTILMEMIS };
  });
  esit('468 kayıtta ortam alanı yok', i4.belirtilmemis, 468);
  esit('49 kayıt Animasyon', i4.animasyon, 49);
  esit('0 kayıt açıkça Canlı aksiyon', i4.canli, 0);
  dogru('Bilinmeyen ortam "Canlı aksiyon" filtresine GİRMEZ', i4.canliGecti === false);
  dogru('Bilinmeyen ortam "Belirtilmemiş" filtresine GİRER', i4.belirsizGecti === true);
  esit('Belirtilmemiş sentinel değeri', i4.sentinel, 'Belirtilmemiş');

  // ============================================================
  console.log('\n== I5) Konu 1 — geri alma iki anahtarı journal ile birlikte yükler ==');
  const i5 = await page.evaluate((key, uyKey, bk, ubk) => {
    localStorage.clear(); state = {}; uygunlukState = {};
    // Mevcut durum (yeni) ve yedek (eski).
    localStorage.setItem(key, JSON.stringify({ 'F-001': { rating: 9 } }));
    localStorage.setItem(uyKey, JSON.stringify({ 'F-001': { id: 'F-001', kategoriler: { siddet: 'yogun' } } }));
    localStorage.setItem(bk, JSON.stringify({ 'F-001': { rating: 3 } }));
    localStorage.setItem(ubk, JSON.stringify({ 'F-001': { id: 'F-001', kategoriler: { siddet: 'hafif' } } }));
    const r = geriAl();
    return {
      r,
      kullanici: JSON.parse(localStorage.getItem(key)),
      uygunluk: JSON.parse(localStorage.getItem(uyKey)),
      journal: localStorage.getItem('personal-film-series-archive-v1__journal'),
    };
  }, 'personal-film-series-archive-v1', 'personal-film-series-archive-v1__uygunluk', 'personal-film-series-archive-v1__backup', 'personal-film-series-archive-v1__uygunluk-backup');
  dogru('Geri alma ok', i5.r.ok);
  esit('Kullanıcı yedekten yüklendi', i5.kullanici['F-001'].rating, 3);
  esit('Uygunluk yedekten yüklendi', i5.uygunluk['F-001'].kategoriler.siddet, 'hafif');
  esit('Geri alma sonrası journal temizlendi', i5.journal, null);

  // Uygunluk yedeği yoksa: mevcut uygunluk verisi korunur (kayıp yok).
  const i5b = await page.evaluate((key, uyKey, bk, ubk) => {
    localStorage.clear(); state = {}; uygunlukState = {};
    localStorage.setItem(key, JSON.stringify({ 'F-001': { rating: 9 } }));
    localStorage.setItem(uyKey, JSON.stringify({ 'F-001': { id: 'F-001', kategoriler: { madde: 'orta' } } }));
    localStorage.setItem(bk, JSON.stringify({ 'F-001': { rating: 3 } }));
    localStorage.removeItem(ubk);
    const r = geriAl();
    return { r, uygunluk: JSON.parse(localStorage.getItem(uyKey)) };
  }, 'personal-film-series-archive-v1', 'personal-film-series-archive-v1__uygunluk', 'personal-film-series-archive-v1__backup', 'personal-film-series-archive-v1__uygunluk-backup');
  dogru('Uygunluk yedeği yok → ok', i5b.r.ok);
  esit('Uygunluk yedeği yok → mevcut korundu', i5b.uygunluk['F-001'].kategoriler.madde, 'orta');
  dogru('uygunlukVar=false bildirildi', i5b.r.uygunlukVar === false);

  // İkinci yazım (uygunluk) başarısız VE geri döndürme de başarısız olursa:
  // tutarsız kalmasın diye journal KORUNUR (sonraki açılışta kurtarılır).
  const i5c = await page.evaluate((key, uyKey, bk, ubk, jKey) => {
    localStorage.clear(); state = {}; uygunlukState = {};
    localStorage.setItem(key, JSON.stringify({ 'F-001': { rating: 9 } }));
    localStorage.setItem(uyKey, JSON.stringify({ 'F-001': { id: 'F-001', kategoriler: { siddet: 'yogun' } } }));
    localStorage.setItem(bk, JSON.stringify({ 'F-001': { rating: 3 } }));
    localStorage.setItem(ubk, JSON.stringify({ 'F-001': { id: 'F-001', kategoriler: { siddet: 'hafif' } } }));
    const orig = localStorage.setItem.bind(localStorage);
    // Uygunluk anahtarına yazım sürekli başarısız → geri döndürme de yapılamaz.
    localStorage.setItem = function (k, v) { if (k === uyKey) throw new Error('uygunluk yazılamadı'); return orig(k, v); };
    const r = geriAl();
    localStorage.setItem = orig;
    return {
      r,
      kullanici: JSON.parse(localStorage.getItem(key)),
      uygunluk: JSON.parse(localStorage.getItem(uyKey)),
      journal: localStorage.getItem(jKey),
    };
  }, 'personal-film-series-archive-v1', 'personal-film-series-archive-v1__uygunluk', 'personal-film-series-archive-v1__backup', 'personal-film-series-archive-v1__uygunluk-backup', 'personal-film-series-archive-v1__journal');
  dogru('Yazma hatası → ok=false', i5c.r.ok === false);
  dogru('Yazma hatası → geri döndürme başarısız bildirildi', i5c.r.kurtarildi === false);
  esit('Yazma hatası → kullanıcı ESKİ hâle döndü', i5c.kullanici['F-001'].rating, 9);
  esit('Yazma hatası → uygunluk ESKİ hâlde (yazılamadı)', i5c.uygunluk['F-001'].kategoriler.siddet, 'yogun');
  dogru('Yazma hatası → journal KORUNDU (sonraki açılışta kurtarılır)', i5c.journal !== null);

  // Tek seferlik yazma hatası → geri döndürme BAŞARILI → journal temizlenir, iki anahtar eski hâle döner.
  const i5d = await page.evaluate((key, uyKey, bk, ubk, jKey) => {
    localStorage.clear(); state = {}; uygunlukState = {};
    localStorage.setItem(key, JSON.stringify({ 'F-001': { rating: 9 } }));
    localStorage.setItem(uyKey, JSON.stringify({ 'F-001': { id: 'F-001', kategoriler: { siddet: 'yogun' } } }));
    localStorage.setItem(bk, JSON.stringify({ 'F-001': { rating: 3 } }));
    localStorage.setItem(ubk, JSON.stringify({ 'F-001': { id: 'F-001', kategoriler: { siddet: 'hafif' } } }));
    const orig = localStorage.setItem.bind(localStorage);
    let sayac = 0;
    // Yalnızca İLK uygunluk yazımı başarısız; geri döndürme yazımı başarılı olur.
    localStorage.setItem = function (k, v) {
      if (k === uyKey) { sayac++; if (sayac === 1) throw new Error('uygunluk yazılamadı (tek seferlik)'); }
      return orig(k, v);
    };
    const r = geriAl();
    localStorage.setItem = orig;
    return {
      r,
      kullanici: JSON.parse(localStorage.getItem(key)),
      uygunluk: JSON.parse(localStorage.getItem(uyKey)),
      journal: localStorage.getItem(jKey),
    };
  }, 'personal-film-series-archive-v1', 'personal-film-series-archive-v1__uygunluk', 'personal-film-series-archive-v1__backup', 'personal-film-series-archive-v1__uygunluk-backup', 'personal-film-series-archive-v1__journal');
  dogru('Tek seferlik hata → ok=false', i5d.r.ok === false);
  esit('Tek seferlik hata → kullanıcı ESKİ hâle döndü', i5d.kullanici['F-001'].rating, 9);
  esit('Tek seferlik hata → uygunluk ESKİ hâle döndü', i5d.uygunluk['F-001'].kategoriler.siddet, 'yogun');
  esit('Tek seferlik hata → journal temizlendi (tutarlı)', i5d.journal, null);

  // ============================================================
  console.log('\n== I6) Konu 2 — kurtarma başarısızsa veri kilidi ==');
  const i6 = await page.evaluate((key, uyKey, jKey) => {
    localStorage.clear(); state = {}; uygunlukState = {}; setVeriKilitli(false);
    localStorage.setItem(key, JSON.stringify({ 'F-001': { rating: 5 } }));
    // Bozuk journal: journalOku null döner → kurtarma denenmez.
    localStorage.setItem(jKey, '{bozuk');
    const kurtarma = journalKurtar();
    return { kurtarma, kilit: veriKilitliMi() };
  }, 'personal-film-series-archive-v1', 'personal-film-series-archive-v1__uygunluk', 'personal-film-series-archive-v1__journal');
  esit('Bozuk journal → kurtarma null (kurtarma yok)', i6.kurtarma, null);
  dogru('Bozuk journal tek başına kilitlemez', i6.kilit === false);

  // Kilit aktifken: update engellenir, uygunlukDuzelt engellenir, içe aktarma engellenir.
  const i6b = await page.evaluate((key) => {
    localStorage.clear(); state = { 'F-001': { rating: 5 } }; uygunlukState = {}; setVeriKilitli(true);
    localStorage.setItem(key, JSON.stringify(state));
    // update → engellenmeli (state değişmemeli)
    update('F-001', 'rating', 10);
    const sonraState = JSON.parse(localStorage.getItem(key));
    // uygunlukDuzelt → null dönmeli, yazmamalı
    const duz = uygunlukDuzelt('F-001', 'kategori', { kategori: 'siddet', seviye: 'yogun' });
    const uyHam = localStorage.getItem('personal-film-series-archive-v1__uygunluk');
    const kilit = veriKilitliMi();
    setVeriKilitli(false);
    return { sonraState, duz, uyHam, kilit };
  }, 'personal-film-series-archive-v1');
  esit('Kilit: update puanı değiştirmedi', i6b.sonraState['F-001'].rating, 5);
  esit('Kilit: uygunlukDuzelt null döndü', i6b.duz, null);
  esit('Kilit: uygunluk yazılmadı', i6b.uyHam, null);
  dogru('Kilit aktif doğrulandı', i6b.kilit);

  // Kurtarma başarılı olduğunda kilit kalkar ve normal çalışma sürer.
  const i6c = await page.evaluate((key, uyKey, jKey) => {
    localStorage.clear(); state = {}; uygunlukState = {}; setVeriKilitli(false);
    // Yarım kalmış journal → kurtarma 'geri-alindi' olmalı, kilit AÇILMAMALI.
    localStorage.setItem(key, JSON.stringify({ 'F-002': { rating: 1 } }));
    localStorage.setItem(uyKey, JSON.stringify({}));
    localStorage.setItem(jKey, JSON.stringify({
      kullanici: { 'F-003': { rating: 7 } }, uygunluk: {},
      eskiKullanici: JSON.stringify({ 'F-001': { rating: 5 } }), eskiUygunluk: JSON.stringify({}),
      ts: Date.now(),
    }));
    const kurtarma = journalKurtar();
    // Başarılı kurtarma sonrası veri değişikliği çalışmalı.
    state = JSON.parse(localStorage.getItem(key));
    update('F-001', 'rating', 4);
    return { tur: kurtarma.kurtarildi, sonra: JSON.parse(localStorage.getItem(key)) };
  }, 'personal-film-series-archive-v1', 'personal-film-series-archive-v1__uygunluk', 'personal-film-series-archive-v1__journal');
  esit('Başarılı kurtarma türü geri-alindi', i6c.tur, 'geri-alindi');
  esit('Başarılı kurtarma sonrası normal yazım çalışıyor', i6c.sonra['F-001'].rating, 4);

  // baslat(): kurtarma başarısızsa kilit kurulur (kaynak kod akışı taklidi).
  const i6d = await page.evaluate((key, jKey) => {
    localStorage.clear(); state = {}; uygunlukState = {}; setVeriKilitli(false);
    localStorage.setItem(key, JSON.stringify({ 'F-001': { rating: 5 } }));
    // Kurtarma yazımını boz: journal geçerli ama eski değere dönüş yazımı başarısız olacak.
    const orig = localStorage.setItem.bind(localStorage);
    localStorage.setItem(jKey, JSON.stringify({
      kullanici: { 'F-003': { rating: 7 } }, uygunluk: {},
      eskiKullanici: JSON.stringify({ 'F-001': { rating: 5 } }), eskiUygunluk: JSON.stringify({}),
      ts: Date.now(),
    }));
    // KEY yazımını boz → kurtarma 'basarisiz' dönmeli.
    localStorage.setItem = function (k, v) { if (k === key) throw new Error('kurtarma yazılamadı'); return orig(k, v); };
    const kurtarma = journalKurtar();
    localStorage.setItem = orig;
    // baslat() mantığı: basarisiz ise kilitle.
    if (kurtarma && kurtarma.kurtarildi === 'basarisiz') setVeriKilitli(true);
    const kilit = veriKilitliMi();
    setVeriKilitli(false);
    return { tur: kurtarma ? kurtarma.kurtarildi : null, kilit };
  }, 'personal-film-series-archive-v1', 'personal-film-series-archive-v1__journal');
  esit('Kurtarma başarısız türü', i6d.tur, 'basarisiz');
  dogru('Kurtarma başarısız → veri kilidi kuruldu', i6d.kilit);

  // Kilit aktifken içe aktarma (iceAktarmaUygula) engellenir; veri değişmez.
  const i6e = await page.evaluate((key) => {
    localStorage.clear(); state = { 'F-001': { rating: 5 } }; uygunlukState = {};
    localStorage.setItem(key, JSON.stringify(state));
    const once = localStorage.getItem(key);
    setVeriKilitli(true);
    // Sahte bekleyen analiz kur ve Değiştir'i çağır.
    bekleyenAnaliz = { ok: true, valid: { 'F-900': { rating: 9 } }, conflicts: [], newIds: ['F-900'], unknownIds: [], invalidValues: [], fileTotal: 1 };
    iceAktarmaUygula('degistir');
    const sonra = localStorage.getItem(key);
    const kilit = veriKilitliMi();
    bekleyenAnaliz = null; setVeriKilitli(false);
    return { once, sonra, kilit };
  }, 'personal-film-series-archive-v1');
  esit('Kilit: içe aktarma veriyi değiştirmedi', i6e.sonra, i6e.once);
  dogru('Kilit aktif doğrulandı (içe aktarma)', i6e.kilit);

  esit('Sayfa hatası yok', hatalar, []);

  await browser.close();
  console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
  process.exit(kalan ? 1 : 0);
})();

// Aşama 2 migration testleri — gerçek Chromium + LocalStorage.
// Çalıştırma: node testler/migrasyon_tarayici.test.js
// Ön koşul: http://localhost:12000 üzerinde yerel sunucu çalışıyor olmalı.
const puppeteer = require('puppeteer-core');
const path = require('path');

const EXEC = '/usr/bin/chromium';
const URL = 'http://localhost:12000/index.html';
const FILE_URL = 'file://' + path.resolve(__dirname, '..', 'index.html');
const KEY = 'personal-film-series-archive-v1';
const META = KEY + '__meta';
const IMP_BACKUP = KEY + '__backup';
const MIG_BACKUP = KEY + '__migration-backup';

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}

// Sayfa yüklenmeden önce LocalStorage hazırla (aynı origin'de gezinip yazıp yeniden yükle).
async function hazirla(page, veri) {
  await page.goto(URL, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.evaluate((d) => {
    if (d.state !== undefined) localStorage.setItem(d.KEY, JSON.stringify(d.state));
    if (d.meta !== undefined) localStorage.setItem(d.META, d.meta);
  }, { KEY, META, state: veri.state, meta: veri.meta });
}

(async () => {
  const browser = await puppeteer.launch({ executablePath: EXEC, headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const alerts = [];
  page.on('dialog', async (d) => { alerts.push(d.message()); await d.accept(); });
  const hatalar = [];
  page.on('pageerror', (e) => hatalar.push(e.message));

  // ===== 1) Eski LocalStorage verisinin migration'ı =====
  console.log('\n== 1) Eski (v1) LocalStorage → v2 migration ==');
  await hazirla(page, { state: { 'F-001': { watched: true, rating: 9 }, 'F-002': { favorite: true } } });
  await page.reload({ waitUntil: 'networkidle0' });
  const meta1 = await page.evaluate((k) => JSON.parse(localStorage.getItem(k) || 'null'), META);
  esit('meta _schema=2 yazıldı', meta1 && meta1._schema, 2);
  esit('meta migratedFrom=1', meta1 && meta1.migratedFrom, 1);
  esit('migration yedeği alındı', await page.evaluate((k) => !!localStorage.getItem(k), MIG_BACKUP), true);
  esit('migration bilgilendirmesi gösterildi', alerts.some((m) => m.includes('şeması güncellendi')), true);
  const state1 = await page.evaluate((k) => JSON.parse(localStorage.getItem(k)), KEY);
  esit('kullanıcı verisi değişmedi (F-001)', state1['F-001'], { watched: true, rating: 9 });
  esit('kullanıcı verisi değişmedi (F-002)', state1['F-002'], { favorite: true });

  // ===== 2) İdempotentlik: yeniden yüklemede tekrar migration yok =====
  console.log('\n== 2) Tekrar yükleme → migration tekrarlanmaz ==');
  alerts.length = 0;
  await page.reload({ waitUntil: 'networkidle0' });
  await new Promise((r) => setTimeout(r, 300));
  esit('ikinci yüklemede migration uyarısı yok', alerts.some((m) => m.includes('şeması güncellendi')), false);
  const meta2 = await page.evaluate((k) => JSON.parse(localStorage.getItem(k)), META);
  esit('meta değişmedi (idempotent)', meta2, { _schema: 2, migratedFrom: 1 });

  // ===== 3) İleri sürüm: sessizce dönüştürme, veriyi koru =====
  console.log('\n== 3) Desteklenmeyen sürüm → veri korunur, uyarı ==');
  await hazirla(page, { state: { 'F-010': { rating: 5 } }, meta: JSON.stringify({ _schema: 99 }) });
  alerts.length = 0;
  await page.reload({ waitUntil: 'networkidle0' });
  await new Promise((r) => setTimeout(r, 300));
  esit('ileri sürüm uyarısı gösterildi', alerts.some((m) => m.includes('Desteklenmeyen şema')), true);
  esit('veri değişmedi', await page.evaluate((k) => localStorage.getItem(k), KEY), JSON.stringify({ 'F-010': { rating: 5 } }));
  esit('meta değişmedi', await page.evaluate((k) => JSON.parse(localStorage.getItem(k))._schema, META), 99);
  esit('ileri sürümde migration yedeği alınmadı', await page.evaluate((k) => localStorage.getItem(k), MIG_BACKUP), null);

  // ===== 4) Bozuk meta: durdur, veri korunur =====
  console.log('\n== 4) Bozuk meta → durdur ==');
  await hazirla(page, { state: { 'F-011': { rating: 6 } }, meta: 'bu json degil' });
  alerts.length = 0;
  await page.reload({ waitUntil: 'networkidle0' });
  await new Promise((r) => setTimeout(r, 300));
  esit('bozuk meta uyarısı gösterildi', alerts.some((m) => m.includes('Bozuk şema')), true);
  esit('veri korundu', await page.evaluate((k) => localStorage.getItem(k), KEY), JSON.stringify({ 'F-011': { rating: 6 } }));

  // ===== 5) Bozuk state JSON: veri değişmez =====
  console.log('\n== 5) Bozuk state JSON → veri korunur ==');
  await hazirla(page, { state: 'yok' });
  await page.evaluate((k) => localStorage.setItem(k, '{ bu json degil'), KEY);
  alerts.length = 0;
  await page.reload({ waitUntil: 'networkidle0' });
  await new Promise((r) => setTimeout(r, 300));
  esit('bozuk state uyarısı gösterildi', alerts.some((m) => m.includes('bozuk JSON')), true);
  esit('bozuk state değiştirilmedi', await page.evaluate((k) => localStorage.getItem(k), KEY), '{ bu json degil');

  // ===== 6) Yedekleme başarısızlığı: migration başlamaz =====
  console.log('\n== 6) Migration yedeği alınamazsa migration başlamaz ==');
  await page.goto(URL, { waitUntil: 'networkidle0' });
  const sonuc6 = await page.evaluate((mk, metaK) => {
    localStorage.removeItem(metaK);
    localStorage.setItem('personal-film-series-archive-v1', JSON.stringify({ 'F-012': { rating: 7 } }));
    const orig = localStorage.setItem.bind(localStorage);
    localStorage.setItem = function (k, v) { if (k === mk) throw new Error('kota dolu'); return orig(k, v); };
    const r = loadState();
    localStorage.setItem = orig;
    return r;
  }, MIG_BACKUP, META);
  esit('yedek alınamadı → ok false', sonuc6.ok, false);
  esit('yedek alınamadı → hata mesajı', sonuc6.error.includes('yedek alınamadı'), true);
  esit('yedek alınamadı → veri değişmedi', await page.evaluate((k) => localStorage.getItem(k), KEY), JSON.stringify({ 'F-012': { rating: 7 } }));
  esit('yedek alınamadı → meta yazılmadı', await page.evaluate((k) => localStorage.getItem(k), META), null);

  // ===== 7) Migration sırasında meta yazma hatası: veri korunur =====
  console.log('\n== 7) Migration yazma hatası → veri korunur ==');
  const sonuc7 = await page.evaluate((mk, metaK) => {
    localStorage.removeItem(metaK);
    localStorage.setItem('personal-film-series-archive-v1', JSON.stringify({ 'F-013': { rating: 8 } }));
    const orig = localStorage.setItem.bind(localStorage);
    localStorage.setItem = function (k, v) { if (k === metaK) throw new Error('yazma hatası'); return orig(k, v); };
    const r = loadState();
    localStorage.setItem = orig;
    return { r, meta: localStorage.getItem(metaK), state: localStorage.getItem('personal-film-series-archive-v1') };
  }, MIG_BACKUP, META);
  esit('yazma hatası → ok false', sonuc7.r.ok, false);
  esit('yazma hatası → hata mesajı', sonuc7.r.error.includes('yazma hatası'), true);
  esit('yazma hatası → meta geri alındı (null)', sonuc7.meta, null);
  esit('yazma hatası → veri korundu', sonuc7.state, JSON.stringify({ 'F-013': { rating: 8 } }));

  // ===== 8) Bilinmeyen alanlar migration sonrası korunur =====
  console.log('\n== 8) Bilinmeyen alanlar korunur ==');
  await hazirla(page, { state: { 'F-014': { watched: true, rating: 9, ozelNot: 'benim notum', etiket: ['a', 'b'] } } });
  await page.reload({ waitUntil: 'networkidle0' });
  const s8 = await page.evaluate((k) => JSON.parse(localStorage.getItem(k)), KEY);
  esit('bilinmeyen ozelNot korundu', s8['F-014'].ozelNot, 'benim notum');
  esit('bilinmeyen etiket korundu', s8['F-014'].etiket, ['a', 'b']);
  esit('bilinen alanlar korundu', { watched: s8['F-014'].watched, rating: s8['F-014'].rating }, { watched: true, rating: 9 });

  // ===== 9) Migration sonrası içe aktarma yedeği anahtarı bozulmaz =====
  console.log('\n== 9) Migration, içe aktarma yedeğini ezmez ==');
  await hazirla(page, { state: { 'F-015': { rating: 3 } } });
  await page.evaluate((k) => localStorage.setItem(k, JSON.stringify({ 'F-999': { rating: 1 } })), IMP_BACKUP);
  await page.reload({ waitUntil: 'networkidle0' });
  esit('içe aktarma yedeği korundu', await page.evaluate((k) => JSON.parse(localStorage.getItem(k)), IMP_BACKUP), { 'F-999': { rating: 1 } });
  esit('migration yedeği ayrı anahtarda', await page.evaluate((k) => !!localStorage.getItem(k), MIG_BACKUP), true);

  // ===== 10) Geri alma + geriye dönük uyumluluk =====
  console.log('\n== 10) Geri al ve katalog bütünlüğü ==');
  esit('katalog hâlâ 517', await page.evaluate(() => catalog.length), 517);
  esit('ilk ID F-001', await page.evaluate(() => catalog[0].id), 'F-001');
  esit('son ID D-178', await page.evaluate(() => catalog[catalog.length - 1].id), 'D-178');

  // ===== 10b) Eski JSON yedeğinin içe aktarılması (v1 biçimi) =====
  console.log('\n== 10b) Eski JSON yedeği içe aktarma ==');
  await hazirla(page, { state: { 'F-030': { rating: 2 } } });
  await page.reload({ waitUntil: 'networkidle0' });
  await page.evaluate(() => {
    const obj = { version: 1, exportedAt: '2020-01-01T00:00:00.000Z', ratingsAndPreferences: {
      'F-030': { watched: true, rating: 9, favorite: true },
      'F-031': { watched: false, rank: 5 },
    } };
    const file = new File([JSON.stringify(obj)], 'eski.json', { type: 'application/json' });
    const dt = new DataTransfer(); dt.items.add(file);
    const i = document.getElementById('file'); i.files = dt.files; i.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await page.waitForFunction(() => !document.getElementById('iceModal').classList.contains('hidden'));
  await page.click('#iceBirlestir');
  await new Promise((r) => setTimeout(r, 400));
  const s10b = await page.evaluate((k) => JSON.parse(localStorage.getItem(k)), KEY);
  esit('eski yedek: F-030 güncellendi (watched korundu)', s10b['F-030'], { rating: 9, watched: true, favorite: true });
  esit('eski yedek: F-031 eklendi', s10b['F-031'], { watched: false, rank: 5 });
  esit('eski yedek sonrası meta hâlâ v2', await page.evaluate((k) => JSON.parse(localStorage.getItem(k))._schema, META), 2);

  // ===== 10c) Geri al: eski şema geri gelirse migration yeniden değerlendirilir =====
  console.log('\n== 10c) Geri al sonrası şema tutarlılığı ==');
  const geriSonuc = await page.evaluate((bk, metaK, key) => {
    localStorage.setItem(bk, JSON.stringify({ 'F-040': { watched: true } }));
    localStorage.removeItem(metaK);
    const ok = restoreBackup();
    return { ok, meta: localStorage.getItem(metaK), state: localStorage.getItem(key) };
  }, IMP_BACKUP, META, KEY);
  esit('geri al başarılı', geriSonuc.ok, true);
  esit('geri al sonrası meta yeniden v2', JSON.parse(geriSonuc.meta)._schema, 2);
  esit('geri al sonrası veri doğru', JSON.parse(geriSonuc.state), { 'F-040': { watched: true } });

  // ===== 11) Çevrimdışı (file://) migration =====
  console.log('\n== 11) Çevrimdışı (file://) migration ==');
  const page2 = await browser.newPage();
  const alerts2 = [];
  page2.on('dialog', async (d) => { alerts2.push(d.message()); await d.accept(); });
  const hatalar2 = [];
  page2.on('pageerror', (e) => hatalar2.push(e.message));
  await page2.goto(FILE_URL, { waitUntil: 'load' });
  await page2.evaluate((k) => localStorage.clear(), KEY);
  await page2.evaluate((k) => localStorage.setItem(k, JSON.stringify({ 'F-020': { watched: true, rating: 10 } })), KEY);
  await page2.reload({ waitUntil: 'load' });
  await new Promise((r) => setTimeout(r, 300));
  const metaFile = await page2.evaluate((k) => JSON.parse(localStorage.getItem(k) || 'null'), META);
  esit('file:// migration meta yazıldı', metaFile && metaFile._schema, 2);
  esit('file:// migration bilgisi gösterildi', alerts2.some((m) => m.includes('şeması güncellendi')), true);
  esit('file:// veri korundu', await page2.evaluate((k) => JSON.parse(localStorage.getItem(k))['F-020'].rating, KEY), 10);
  esit('file:// katalog 517', await page2.evaluate(() => catalog.length), 517);
  esit('file:// sayfa hatası yok', hatalar2, []);

  esit('Sayfa hatası yok (ana sayfa)', hatalar, []);

  await browser.close();
  console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
  if (hatalar.length || hatalar2.length) console.log('HATALAR:', hatalar, hatalar2);
  process.exit(kalan ? 1 : 0);
})();

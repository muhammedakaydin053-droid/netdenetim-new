// Aşama 1 içe aktarma mantığı testleri (saf fonksiyonlar).
// Çalıştırma: node testler/iceaktarma.test.js
const fs = require('fs');
const path = require('path');
const { analizEt, hesaplaYeniDurum, raporOlustur } = require('../js/iceaktarma.js');

// Katalogu gerçek dosyadan yükle (doğrulanmış kaynak).
const veriSrc = fs.readFileSync(path.join(__dirname, '..', 'js', 'veri.js'), 'utf8');
const catalog = eval('(' + veriSrc.replace(/^const catalog=/, '').replace(/;\s*$/, '') + ')');

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}
function dogru(ad, kosul) { esit(ad, !!kosul, true); }

console.log('== Katalog taban ==');
esit('kayıt sayısı 517', catalog.length, 517);

console.log('\n== 1) Geçerli dosya analizi ==');
const dosya1 = {
  version: 1,
  exportedAt: '2025-01-01T00:00:00.000Z',
  ratingsAndPreferences: {
    'F-001': { watched: true, rating: 10, favorite: true, rank: 1 },
    'F-002': { watched: false, rating: 8 },
    'D-001': { watched: true },
  },
};
const mevcut1 = { 'F-001': { watched: true, rating: 9 } };
let a = analizEt(dosya1, catalog, mevcut1);
dogru('ok=true', a.ok);
esit('fileTotal', a.fileTotal, 3);
esit('geçerli kayıt', Object.keys(a.valid).length, 3);
esit('yeni kayıt (F-002,D-001)', a.newIds.sort(), ['D-001', 'F-002']);
esit('çakışan kayıt (F-001)', a.conflicts.length, 1);
esit('bilinmeyen ID yok', a.unknownIds.length, 0);
esit('geçersiz değer yok', a.invalidValues.length, 0);

console.log('\n== 2) Birleştir modu ==');
let yeni = hesaplaYeniDurum('birlestir', a, mevcut1);
esit('F-001 dosyadaki değere güncellendi', yeni['F-001'], { watched: true, rating: 10, favorite: true, rank: 1 });
esit('F-002 eklendi', yeni['F-002'], { watched: false, rating: 8 });
esit('D-001 eklendi', yeni['D-001'], { watched: true });
esit('toplam kayıt 3', Object.keys(yeni).length, 3);

console.log('\n== 3) Birleştir: dosyada olmayan mevcut kayıt korunur ==');
const mevcut3 = { 'F-001': { rating: 5 }, 'F-300': { favorite: true } };
const dosya3 = { version: 1, ratingsAndPreferences: { 'F-001': { rating: 7 } } };
let a3 = analizEt(dosya3, catalog, mevcut3);
let y3 = hesaplaYeniDurum('birlestir', a3, mevcut3);
esit('F-300 korundu', y3['F-300'], { favorite: true });
esit('F-001 güncellendi', y3['F-001'], { rating: 7 });
esit('toplam 2', Object.keys(y3).length, 2);

console.log('\n== 4) Değiştir modu ==');
let y4 = hesaplaYeniDurum('degistir', a, mevcut1);
esit('yalnızca dosyadaki geçerli kayıtlar', Object.keys(y4).sort(), ['D-001', 'F-001', 'F-002']);
const r4 = raporOlustur('degistir', a, mevcut1, y4);
esit('değiştir modunda korunan = 0', r4.korunan, 0);

console.log('\n== 5) Bilinmeyen ID ==');
const dosya5 = { version: 1, ratingsAndPreferences: { 'F-999': { watched: true }, 'X-000': { rating: 5 }, 'F-001': { rating: 3 } } };
let a5 = analizEt(dosya5, catalog, {});
esit('bilinmeyen ID listesi', a5.unknownIds.sort(), ['F-999', 'X-000']);
esit('geçerli yalnızca F-001', Object.keys(a5.valid), ['F-001']);

console.log('\n== 6) Geçersiz değerler ==');
const dosya6 = { version: 1, ratingsAndPreferences: { 'F-001': { rating: 0, rank: -1, watched: 'yes', favorite: true } } };
let a6 = analizEt(dosya6, catalog, {});
esit('geçersiz değer sayısı 3', a6.invalidValues.length, 3);
esit('geçerli alan yalnızca favorite', Object.keys(a6.valid['F-001']), ['favorite']);

console.log('\n== 7) Bozuk/uyumsuz dosyalar (veri değişmez) ==');
dogru('null dosya reddi', analizEt(null, catalog, {}).ok === false);
dogru('dizi reddi', analizEt([1, 2], catalog, {}).ok === false);
dogru('ratingsAndPreferences yok', analizEt({ version: 1 }, catalog, {}).ok === false);
dogru('ratingsAndPreferences dizi', analizEt({ ratingsAndPreferences: [] }, catalog, {}).ok === false);
dogru('desteklenmeyen sürüm (3)', analizEt({ version: 3, ratingsAndPreferences: {} }, catalog, {}).ok === false);
dogru('v2 yedeği kabul edilir', analizEt({ version: 2, ratingsAndPreferences: {}, uygunluk: {} }, catalog, {}).ok === true);
dogru('geçersiz sürüm (-1)', analizEt({ version: -1, ratingsAndPreferences: {} }, catalog, {}).ok === false);

console.log('\n== 8) Geriye dönük uyumluluk ==');
dogru('sürüm alanı yoksa v1 kabul', analizEt({ ratingsAndPreferences: { 'F-001': { rating: 5 } } }, catalog, {}).ok === true);
const a8 = analizEt({ ratingsAndPreferences: { 'F-001': { rating: 5 } } }, catalog, {});
esit('sürüm yoksa version=1', a8.version, 1);

console.log('\n== 9) Boş dosya / boş mevcut ==');
const a9 = analizEt({ version: 1, ratingsAndPreferences: {} }, catalog, {});
dogru('boş dosya geçerli', a9.ok);
esit('boş dosyada geçerli 0', Object.keys(a9.valid).length, 0);

console.log('\n== 10) Rapor sayıları (birleştir) ==');
const mevcut10 = { 'F-001': { rating: 5 }, 'F-300': { favorite: true } };
const dosya10 = { version: 1, ratingsAndPreferences: { 'F-001': { rating: 7 }, 'F-999': { watched: true }, 'F-002': { rating: 99 } } };
const a10 = analizEt(dosya10, catalog, mevcut10);
const y10 = hesaplaYeniDurum('birlestir', a10, mevcut10);
const r10 = raporOlustur('birlestir', a10, mevcut10, y10);
esit('aktarılan', r10.aktarilan, 1);
esit('korunan', r10.korunan, 1);
esit('atılan', r10.atilan, 2);
esit('bilinmeyen ID', r10.bilinmeyenId, 1);
esit('geçersiz değer', r10.gecersizDeger, 1);
esit('sonuç kayıt sayısı', r10.sonucKayitSayisi, 2);

console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
process.exit(kalan ? 1 : 0);

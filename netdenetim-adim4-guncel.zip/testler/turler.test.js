// Aşama 3.1 — Taksonomi ve doğrulama testleri (saf fonksiyonlar).
// Çalıştırma: node testler/turler.test.js
const T = require('../js/turler.js');

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}

console.log('== Sabitler: ana türler ==');
esit('19 ana tür', T.ANA_TURLER.length, 19);
esit('ana türler tekil', new Set(T.ANA_TURLER).size, 19);
esit('Gençlik ana tür DEĞİL', T.ANA_TURLER.includes('Gençlik'), false);
esit('Aile ana tür', T.ANA_TURLER.includes('Aile'), true);
esit('Felaket ana tür', T.ANA_TURLER.includes('Felaket'), true);
esit('Biyografi ana tür', T.ANA_TURLER.includes('Biyografi'), true);
esit('Spor ana tür', T.ANA_TURLER.includes('Spor'), true);
esit('Müzik ana tür', T.ANA_TURLER.includes('Müzik'), true);
esit('Animasyon ana tür DEĞİL', T.ANA_TURLER.includes('Animasyon'), false);
esit('Anime ana tür DEĞİL', T.ANA_TURLER.includes('Anime'), false);
esit('Mini dizi ana tür DEĞİL', T.ANA_TURLER.includes('Mini dizi'), false);

console.log('\n== Sabitler: alt türler ve bağlı ana türler ==');
esit('6 alt tür', T.ALT_TURLER.length, 6);
esit('Gangster → Suç', T.ALT_TUR_ANA['Gangster'], 'Suç');
esit('Polisiye → Suç', T.ALT_TUR_ANA['Polisiye'], 'Suç');
esit('Dedektif → Gizem', T.ALT_TUR_ANA['Dedektif'], 'Gizem');
esit('Psikolojik → Gerilim', T.ALT_TUR_ANA['Psikolojik'], 'Gerilim');
esit('Casusluk → Aksiyon', T.ALT_TUR_ANA['Casusluk'], 'Aksiyon');
esit('Hayatta kalma → Felaket', T.ALT_TUR_ANA['Hayatta kalma'], 'Felaket');
esit('Distopya alt tür DEĞİL', T.ALT_TURLER.includes('Distopya'), false);
esit('her alt türün ana türü geçerli', T.ALT_TURLER.every((a) => T.anaTurGecerliMi(T.ALT_TUR_ANA[a])), true);
esit('altTurunAnaTuru(Dedektif)', T.altTurunAnaTuru('Dedektif'), 'Gizem');
esit('altTurunAnaTuru(bilinmeyen)', T.altTurunAnaTuru('Yok'), undefined);

console.log('\n== Sabitler: etiketler ==');
esit('6 etiket', T.ETIKETLER.length, 6);
esit('Klasik var', T.ETIKETLER.includes('Klasik'), true);
esit('Dünya sineması var', T.ETIKETLER.includes('Dünya sineması'), true);
esit('Bağımsız/Sanat sineması var', T.ETIKETLER.includes('Bağımsız/Sanat sineması'), true);
esit('Gerçek olay var', T.ETIKETLER.includes('Gerçek olay'), true);
esit('Karakter odaklı etiket DEĞİL', T.ETIKETLER.includes('Karakter odaklı'), false);
esit('Okul var', T.ETIKETLER.includes('Okul'), true);
esit('Gençlik etiket olarak var', T.ETIKETLER.includes('Gençlik'), true);
esit('Sıcak hikâye etiket DEĞİL', T.ETIKETLER.includes('Sıcak hikâye'), false);

console.log('\n== Sabitler: özellik değerleri ==');
esit('ortam değerleri', T.ORTAM_DEGERLERI, ['Animasyon', 'Canlı aksiyon']);
esit('ortam belirtilmemiş sentinel', T.ORTAM_BELIRTILMEMIS, 'Belirtilmemiş');
esit('animasyonGelenegi değerleri', T.ANIMASYON_GELENEGI_DEGERLERI, ['Anime', 'Batı']);
esit('bicim değerleri', T.BICIM_DEGERLERI, ['Mini dizi']);

console.log('\n== Yardımcı doğrulayıcılar ==');
esit('anaTurGecerliMi(Dram)', T.anaTurGecerliMi('Dram'), true);
esit('anaTurGecerliMi(Animasyon)', T.anaTurGecerliMi('Animasyon'), false);
esit('altTurGecerliMi(Gangster)', T.altTurGecerliMi('Gangster'), true);
esit('etiketGecerliMi(Klasik)', T.etiketGecerliMi('Klasik'), true);
esit('ortamGecerliMi(Animasyon)', T.ortamGecerliMi('Animasyon'), true);
// Denetim bulgusu 4: ortam alanı yokluğu "Canlı aksiyon" değil, "bilinmiyor" sayılır.
esit('ortamBelirtilmemisMi(alan yok)', T.ortamBelirtilmemisMi({ id: 'F-001' }), true);
esit('ortamBelirtilmemisMi(boş string)', T.ortamBelirtilmemisMi({ id: 'F-001', ortam: '' }), true);
esit('ortamBelirtilmemisMi(Animasyon) false', T.ortamBelirtilmemisMi({ id: 'F-001', ortam: 'Animasyon' }), false);
esit('ortamBelirtilmemisMi(Canlı aksiyon) false', T.ortamBelirtilmemisMi({ id: 'F-001', ortam: 'Canlı aksiyon' }), false);
esit('animasyonGelenegiGecerliMi(Anime)', T.animasyonGelenegiGecerliMi('Anime'), true);
esit('bicimGecerliMi(Mini dizi)', T.bicimGecerliMi('Mini dizi'), true);

console.log('\n== kayitDogrula: geçerli kayıtlar ==');
let k1 = T.kayitDogrula({ id: 'F-001', turler: ['Suç'] });
esit('tek ana tür → ok', k1.ok, true);
esit('tek ana tür → hata yok', k1.hatalar, []);
esit('tek ana tür → temiz', k1.temiz.turler, ['Suç']);

let k2 = T.kayitDogrula({ id: 'F-174', turler: ['Aksiyon', 'Bilim kurgu', 'Macera'], ortam: 'Animasyon', animasyonGelenegi: 'Batı' });
esit('çoklu tür + animasyon → ok', k2.ok, true);
esit('çoklu tür → uyarı yok', k2.uyarilar, []);

console.log('\n== kayitDogrula: boş turler istisnası (KRİTİK) ==');
let b1 = T.kayitDogrula({ id: 'F-315', turler: [], gozdenGecir: true, etiketler: ['Dünya sineması'] });
esit('turler:[] + gozdenGecir:true → ok', b1.ok, true);
esit('turler:[] + gozdenGecir:true → hata yok', b1.hatalar, []);
let b2 = T.kayitDogrula({ id: 'F-186', turler: [] });
esit('turler:[] + gozdenGecir yok → GEÇERSİZ', b2.ok, false);
esit('turler:[] + gozdenGecir yok → hata mesajı', b2.hatalar.some((h) => h.includes('turler boş')), true);
let b3 = T.kayitDogrula({ id: 'F-190', turler: [], gozdenGecir: false });
esit('turler:[] + gozdenGecir:false → GEÇERSİZ', b3.ok, false);
let b4 = T.kayitDogrula({ id: 'X', turler: [], gozdenGecir: true, gozdenGecirGerekli: true });
esit('gozdenGecir:true ile boş turler her durumda ok', b4.ok, true);

console.log('\n== kayitDogrula: geçersiz ana türler ==');
let g1 = T.kayitDogrula({ id: 'F-001', turler: ['Animasyon'] });
esit('geçersiz ana tür (Animasyon) → ok false', g1.ok, false);
esit('geçersiz ana tür hata mesajı', g1.hatalar.some((h) => h.includes('geçersiz ana tür')), true);
let g2 = T.kayitDogrula({ id: 'F-001', turler: ['Suç', 'YokBöyleTür'] });
esit('karışık geçerli+geçersiz → ok false', g2.ok, false);
esit('temiz yalnızca geçerliyi tutar', g2.temiz.turler, ['Suç']);
let g3 = T.kayitDogrula({ id: 'F-001', turler: 'Dram' });
esit('turler dizi değil → ok false', g3.ok, false);
let g4 = T.kayitDogrula({ id: 'F-001' });
esit('turler alanı yok → ok false', g4.ok, false);
let g5 = T.kayitDogrula({ id: 'F-001', turler: ['Dram', 'Dram'] });
esit('tekrar eden ana tür → ok false', g5.ok, false);
esit('tekrar eden ana tür temizlenir', g5.temiz.turler, ['Dram']);

console.log('\n== kayitDogrula: alt tür–ana tür uyumu ==');
let a1 = T.kayitDogrula({ id: 'F-001', turler: ['Suç'], altTurler: ['Gangster'] });
esit('alt tür + ana türü var → ok', a1.ok, true);
esit('alt tür + ana türü var → uyarı yok', a1.uyarilar, []);
esit('alt tür + ana türü var → gozdenGecirGerekli false', a1.gozdenGecirGerekli, false);

let a2 = T.kayitDogrula({ id: 'D-143', turler: ['Bilim kurgu', 'Dram'], altTurler: ['Psikolojik'] });
esit('alt tür var ama ana türü (Gerilim) yok → ok true (silinmez)', a2.ok, true);
esit('alt tür uyumsuz → uyarı var', a2.uyarilar.length > 0, true);
esit('alt tür uyumsuz → gozdenGecirGerekli true', a2.gozdenGecirGerekli, true);
esit('alt tür uyumsuz → uyarı mesajı', a2.uyarilar[0].includes('Psikolojik') && a2.uyarilar[0].includes('Gerilim'), true);

let a3 = T.kayitDogrula({ id: 'F-001', turler: ['Suç'], altTurler: ['YokBöyleAltTür'] });
esit('geçersiz alt tür → ok false', a3.ok, false);
let a4 = T.kayitDogrula({ id: 'F-001', turler: ['Suç'], altTurler: ['Gangster', 'Gangster'] });
esit('tekrar eden alt tür → ok false', a4.ok, false);
let a5 = T.kayitDogrula({ id: 'F-001', turler: ['Suç'], altTurler: 'Gangster' });
esit('altTurler dizi değil → ok false', a5.ok, false);

console.log('\n== kayitDogrula: etiketler ==');
let e1 = T.kayitDogrula({ id: 'F-228', turler: ['Dram'], etiketler: ['Klasik'] });
esit('geçerli etiket → ok', e1.ok, true);
esit('geçerli etiket → temiz', e1.temiz.etiketler, ['Klasik']);
let e2 = T.kayitDogrula({ id: 'F-001', turler: ['Dram'], etiketler: ['Sıcak hikâye'] });
esit('onaysız etiket (Sıcak hikâye) → ok false', e2.ok, false);
let e3 = T.kayitDogrula({ id: 'F-001', turler: ['Dram'], etiketler: ['Gençlik', 'Okul'] });
esit('yeni onaylı etiketler geçerli', e3.ok, true);
let e4 = T.kayitDogrula({ id: 'F-001', turler: ['Dram'], etiketler: ['Karakter odaklı'] });
esit('Karakter odaklı artık geçersiz', e4.ok, false);

console.log('\n== kayitDogrula: ortam / animasyonGelenegi / bicim ==');
let o1 = T.kayitDogrula({ id: 'D-139', turler: ['Western', 'Dram'], bicim: 'Mini dizi' });
esit('geçerli bicim → ok', o1.ok, true);
let o2 = T.kayitDogrula({ id: 'F-001', turler: ['Dram'], bicim: 'Kısa film' });
esit('geçersiz bicim → ok false', o2.ok, false);
let o3 = T.kayitDogrula({ id: 'F-166', turler: ['Fantastik'], ortam: 'Animasyon', animasyonGelenegi: 'Anime' });
esit('geçerli ortam+gelenek → ok', o3.ok, true);
let o4 = T.kayitDogrula({ id: 'F-001', turler: ['Dram'], ortam: 'Çizgi' });
esit('geçersiz ortam → ok false', o4.ok, false);
let o5 = T.kayitDogrula({ id: 'F-001', turler: ['Dram'], animasyonGelenegi: 'Japon' });
esit('geçersiz animasyonGelenegi → ok false', o5.ok, false);
let o6 = T.kayitDogrula({ id: 'F-001', turler: ['Dram'], animasyonGelenegi: 'Anime' });
esit('gelenek var ama ortam Animasyon değil → ok true', o6.ok, true);
esit('gelenek/ortam uyumsuz → uyarı', o6.uyarilar.some((u) => u.includes('ortam:Animasyon')), true);
esit('gelenek/ortam uyumsuz → gozdenGecirGerekli', o6.gozdenGecirGerekli, true);

console.log('\n== kayitDogrula: bozuk girdi ==');
esit('null → ok false', T.kayitDogrula(null).ok, false);
esit('dizi → ok false', T.kayitDogrula([1, 2]).ok, false);
esit('metin → ok false', T.kayitDogrula('kayıt').ok, false);

console.log('\n== kayitDogrula: kaydı değiştirmez (immutability) ==');
const girdi = { id: 'F-001', turler: ['Suç'], altTurler: ['Gangster'], etiketler: ['Klasik'] };
const kopya = JSON.parse(JSON.stringify(girdi));
T.kayitDogrula(girdi);
esit('girdi nesnesi değişmedi', girdi, kopya);

console.log('\n== Eski alanlara dokunmaz ==');
const eski = { id: 'F-001', title: 'X', kind: 'Film', genre: 'Suç ve gangster', turler: ['Suç'] };
T.kayitDogrula(eski);
esit('genre korundu', eski.genre, 'Suç ve gangster');
esit('kind korundu', eski.kind, 'Film');
esit('temiz çıktıda genre yok (yalnızca yeni alanlar)', 'genre' in T.kayitDogrula(eski).temiz, false);

console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
process.exit(kalan ? 1 : 0);

// Aşama 3.4 Adım 3 — CSV dışa aktarma taksonomi genişletmesi testi.
// Gerçek Chromium (headless) + gerçek katalog verisi. Ön koşul: http://localhost:12000 sunucusu.
// Çalıştırma: node testler/csv.test.js
const puppeteer = require('puppeteer-core');

const EXEC = '/usr/bin/chromium';
const URL = 'http://localhost:12000/index.html';

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}
function dogru(ad, kosul) {
  console.log(`  [${kosul ? 'OK ' : 'HATA'}] ${ad}`);
  kosul ? gecen++ : kalan++;
}

// ";" ayraçlı, her alanı çift tırnaklı CSV'yi ayrıştırır (BOM + CRLF + "" kaçışı).
function csvAyristir(text) {
  const t = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
  const satirlar = [];
  let alanlar = [], alan = '', tirnak = false;
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (tirnak) {
      if (c === '"') { if (t[i + 1] === '"') { alan += '"'; i++; } else tirnak = false; }
      else alan += c;
    } else if (c === '"') tirnak = true;
    else if (c === ';') { alanlar.push(alan); alan = ''; }
    else if (c === '\r') { /* CRLF */ }
    else if (c === '\n') { alanlar.push(alan); satirlar.push(alanlar); alanlar = []; alan = ''; }
    else alan += c;
  }
  if (alan !== '' || alanlar.length) { alanlar.push(alan); satirlar.push(alanlar); }
  return satirlar;
}

async function csvYakala(page) {
  await page.evaluate(() => {
    window.__csv = null;
    window.download = (name, content, type) => { window.__csv = { name, content, type }; };
  });
  await page.click('#csv');
  await page.waitForFunction(() => window.__csv !== null, { timeout: 5000 });
  return page.evaluate(() => window.__csv);
}

(async () => {
  const browser = await puppeteer.launch({ executablePath: EXEC, headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const hatalar = [];
  page.on('pageerror', (e) => hatalar.push('pageerror: ' + e.message));

  await page.goto(URL, { waitUntil: 'networkidle0' });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: 'networkidle0' });

  console.log('== A) CSV yakalama ==');
  const csv = await csvYakala(page);
  esit('Dosya adı', csv.name, 'film-dizi-arsivim.csv');
  esit('MIME türü', csv.type, 'text/csv;charset=utf-8');
  dogru('BOM var (UTF-8)', csv.content.charCodeAt(0) === 0xfeff);
  dogru('CRLF satır sonu kullanılıyor', csv.content.includes('\r\n'));

  const satirlar = csvAyristir(csv.content);
  const baslik = satirlar[0];
  const govde = satirlar.slice(1);
  const col = (ad) => baslik.indexOf(ad);

  console.log('\n== B) Sütun başlıkları ve sırası ==');
  esit('Başlık satırı (7 eski + 7 yeni)', baslik, [
    'title', 'kind', 'genre', 'watched', 'favorite', 'rating', 'rank',
    'turler', 'altTurler', 'etiketler', 'bicim', 'ortam', 'animasyonGelenegi', 'gozdenGecir',
  ]);
  esit('Eski 7 sütun değişmedi', baslik.slice(0, 7), ['title', 'kind', 'genre', 'watched', 'favorite', 'rating', 'rank']);
  esit('Yeni 7 sütun doğru sırada', baslik.slice(7), ['turler', 'altTurler', 'etiketler', 'bicim', 'ortam', 'animasyonGelenegi', 'gozdenGecir']);

  console.log('\n== C) Kayıt sayısı ve sırası ==');
  esit('Toplam 517 veri satırı', govde.length, 517);
  esit('Her satır 14 hücre', [...new Set(govde.map((r) => r.length))], [14]);
  const k = (t) => govde.find((r) => r[0] === t);
  esit('İlk kayıt The Godfather', govde[0][0], 'The Godfather');
  esit('İkinci kayıt The Godfather Part II', govde[1][0], 'The Godfather Part II');
  esit('Son kayıt House of Cards', govde[516][0], 'House of Cards');
  esit('Katalog sırası korundu (Film→Dizi)', [govde[0][col('kind')], govde[516][col('kind')]], ['Film', 'Dizi']);

  console.log('\n== D) Çoklu değerler (turler / altTurler / etiketler) ==');
  esit('F-001 turler = "Suç|Dram"', k('The Godfather')[col('turler')], 'Suç|Dram');
  esit('F-001 altTurler = "Gangster"', k('The Godfather')[col('altTurler')], 'Gangster');
  esit('F-062 4 tür birleşik', k("Schindler's List")[col('turler')], 'Savaş|Dram|Biyografi|Tarih');
  esit('F-062 altTurler boş', k("Schindler's List")[col('altTurler')], '');
  esit('F-314 etiketler = "Dünya sineması"', k('8½')[col('etiketler')], 'Dünya sineması');
  esit('F-186 etiketler = "Bağımsız/Sanat sineması"', k('The Tree of Life')[col('etiketler')], 'Bağımsız/Sanat sineması');

  console.log('\n== E) Boş diziler → boş hücre ==');
  esit('F-314 turler boş hücre', k('8½')[col('turler')], '');
  esit('F-314 altTurler boş hücre', k('8½')[col('altTurler')], '');
  esit('F-315 turler boş hücre', k('Persona')[col('turler')], '');
  esit('F-001 etiketler boş hücre', k('The Godfather')[col('etiketler')], '');

  console.log('\n== F) gozdenGecir ==');
  esit('F-186 gozdenGecir = evet', k('The Tree of Life')[col('gozdenGecir')], 'evet');
  esit('F-314 gozdenGecir = evet', k('8½')[col('gozdenGecir')], 'evet');
  esit('F-001 gozdenGecir = hayır', k('The Godfather')[col('gozdenGecir')], 'hayır');
  esit('F-062 gozdenGecir = hayır', k("Schindler's List")[col('gozdenGecir')], 'hayır');

  console.log('\n== G) bicim / ortam / animasyonGelenegi ==');
  esit('D-131 bicim = Mini dizi', k('Unbelievable')[col('bicim')], 'Mini dizi');
  esit('D-141 ortam = Animasyon', k('Steins;Gate')[col('ortam')], 'Animasyon');
  esit('D-141 animasyonGelenegi = Anime', k('Steins;Gate')[col('animasyonGelenegi')], 'Anime');
  esit('F-001 bicim boş', k('The Godfather')[col('bicim')], '');
  esit('F-001 ortam boş', k('The Godfather')[col('ortam')], '');

  console.log('\n== H) Türkçe karakterler ve eski genre korundu ==');
  esit('F-001 genre = "Suç ve gangster"', k('The Godfather')[col('genre')], 'Suç ve gangster');
  esit('F-001 turler Türkçe korundu', k('The Godfather')[col('turler')], 'Suç|Dram');
  dogru('Türkçe karakter (ç/ş) hücrede var', csv.content.includes('Suç'));

  console.log('\n== I) Kaçış: virgül / noktalı virgül / tırnak ==');
  esit('Virgüllü başlık doğru ayrıştı', k('Crouching Tiger, Hidden Dragon')[0], 'Crouching Tiger, Hidden Dragon');
  esit('Virgüllü satır 14 hücre', k('Crouching Tiger, Hidden Dragon').length, 14);
  esit('Noktalı virgüllü başlık doğru ayrıştı', k('Steins;Gate')[0], 'Steins;Gate');
  esit('Noktalı virgüllü satır 14 hücre', k('Steins;Gate').length, 14);
  const ilkSatir = csv.content.replace(/^\uFEFF/, '').split('\r\n')[1];
  dogru('Ham satırda tüm alanlar çift tırnaklı', ilkSatir.split(';').every((h) => h.startsWith('"') && h.endsWith('"')));
  const kacis = await page.evaluate(() => {
    const esc = (v) => '"' + String(v ?? '').replaceAll('"', '""') + '"';
    return esc('a"b;c\nd');
  });
  esit('esc() tırnak/satır sonu kaçışı', kacis, '"a""b;c\nd"');

  console.log('\n== J) Filtre aktifken CSV davranışı (mevcut davranış korundu) ==');
  // Mevcut CSV tüm katalogu dışa aktarır (filtre kullanmaz). Bu davranış korunmalı.
  await page.evaluate(() => {
    const cb = [...document.querySelectorAll('#turPanel input[type="checkbox"]')].find((c) => c.value === 'Korku');
    cb.checked = true;
    cb.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await page.waitForFunction(() => document.querySelectorAll('#list .item').length === 36);
  const csv2 = await csvYakala(page);
  const govde2 = csvAyristir(csv2.content).slice(1);
  esit('Filtre aktifken CSV yine 517 kayıt (tüm katalog)', govde2.length, 517);
  await page.click('#reset');

  console.log('\n== K) JSON ve PDF işlevleri bozulmadı ==');
  await page.evaluate(() => { window.__json = null; window.download = (name, content) => { window.__json = { name, content }; }; });
  await page.click('#json');
  await page.waitForFunction(() => window.__json !== null);
  const json = await page.evaluate(() => window.__json);
  esit('JSON dosya adı', json.name, 'film-dizi-arsiv-yedegi.json');
  const parsed = JSON.parse(json.content);
  esit('JSON version = 2', parsed.version, 2);
  esit('JSON catalog = 517', parsed.catalog.length, 517);
  dogru('JSON uygunluk alanı var (nesne)', parsed.uygunluk && typeof parsed.uygunluk === 'object');
  dogru('JSON ratingsAndPreferences nesnesi var', parsed.ratingsAndPreferences && typeof parsed.ratingsAndPreferences === 'object');
  const pdfVar = await page.evaluate(() => typeof document.getElementById('pdf').onclick === 'function');
  dogru('PDF düğmesi bağlı', pdfVar);

  console.log('\n== L) Sayfa hatası yok ==');
  esit('pageerror yok', hatalar, []);

  await browser.close();
  console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
  process.exit(kalan ? 1 : 0);
})();

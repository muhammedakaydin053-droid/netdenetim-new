// Aşama 2 — iki anahtarlı yapı tutarlılık kontrolleri (hata simülasyonu).
// Çalıştırma: node testler/anahtar_tutarlilik.test.js
// Ön koşul: http://localhost:12000 üzerinde yerel sunucu çalışıyor olmalı.
const puppeteer = require('puppeteer-core');
const path = require('path');

const EXEC = '/usr/bin/chromium';
const URL = 'http://localhost:12000/index.html';
const FILE_URL = 'file://' + path.resolve(__dirname, '..', 'index.html');
const KEY = 'personal-film-series-archive-v1';
const META = KEY + '__meta';
const IMP_BACKUP = KEY + '__backup';
const MIG_BACKUP = KEY + '__migration-backup';

let gecen = 0, kalan = 0;
function esit(ad, gercek, beklenen) {
  const ok = JSON.stringify(gercek) === JSON.stringify(beklenen);
  console.log(`  [${ok ? 'OK ' : 'HATA'}] ${ad}` + (ok ? '' : ` → gerçek=${JSON.stringify(gercek)} beklenen=${JSON.stringify(beklenen)}`));
  ok ? gecen++ : kalan++;
}

(async () => {
  const browser = await puppeteer.launch({ executablePath: EXEC, headless: 'new', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage();
  const hatalar = [];
  page.on('pageerror', (e) => hatalar.push(e.message));
  page.on('dialog', async (d) => { await d.accept(); });

  await page.goto(URL, { waitUntil: 'networkidle0' });

  // ============================================================
  console.log('\n== S1) State dokunulmaz, meta yazımı başarısız ==');
  // Kod: migration yalnızca META yazar; KEY'e hiç yazmaz. Meta yazımı çökerse
  // state zaten değişmemiştir; meta eski hâline döner.
  const s1 = await page.evaluate((key, meta, mig) => {
    localStorage.clear();
    localStorage.setItem(key, JSON.stringify({ 'F-001': { watched: true, rating: 9 } }));
    const orig = localStorage.setItem.bind(localStorage);
    localStorage.setItem = function (k, v) { if (k === meta) throw new Error('meta yazılamadı'); return orig(k, v); };
    const r = loadState();
    localStorage.setItem = orig;
    return { r, state: localStorage.getItem(key), meta: localStorage.getItem(meta), migBackup: localStorage.getItem(mig) };
  }, KEY, META, MIG_BACKUP);
  esit('S1 ok=false', s1.r.ok, false);
  esit('S1 hata mesajı', s1.r.error.includes('yazma hatası'), true);
  esit('S1 state değişmedi', s1.state, JSON.stringify({ 'F-001': { watched: true, rating: 9 } }));
  esit('S1 meta yazılmadı (null)', s1.meta, null);
  esit('S1 migration yedeği alındı', s1.migBackup !== null, true);
  esit('S1 migration yedeği içeriği doğru', JSON.parse(s1.migBackup), { 'F-001': { watched: true, rating: 9 } });

  // ============================================================
  console.log('\n== S2) restoreBackup: meta sıfırlandı, state yazımı başarısız ==');
  const s2 = await page.evaluate((key, meta, bk) => {
    localStorage.clear();
    localStorage.setItem(key, JSON.stringify({ 'F-050': { rating: 1 } }));   // mevcut
    localStorage.setItem(bk, JSON.stringify({ 'F-051': { rating: 2 } }));    // yedek
    localStorage.setItem(meta, JSON.stringify({ _schema: 2 }));              // v2 meta
    const orig = localStorage.setItem.bind(localStorage);
    localStorage.setItem = function (k, v) { if (k === key) throw new Error('state yazılamadı'); return orig(k, v); };
    const ok = restoreBackup();
    localStorage.setItem = orig;
    return { ok, state: localStorage.getItem(key), meta: localStorage.getItem(meta) };
  }, KEY, META, IMP_BACKUP);
  esit('S2 restoreBackup=false', s2.ok, false);
  esit('S2 state değişmedi', s2.state, JSON.stringify({ 'F-050': { rating: 1 } }));
  esit('S2 meta eski hâline döndü (v2)', JSON.parse(s2.meta)._schema, 2);

  // ============================================================
  console.log('\n== S3) Yazımlar arası çökme (meta silindi, state yazılmadı) ==');
  // Gerçek çökmeyi simüle etmek zor; iki yazım arasındaki ara durumu kurup
  // sayfayı yeniden yükleyerek toparlanmayı doğruluyoruz.
  await page.evaluate((key, meta) => {
    localStorage.clear();
    localStorage.setItem(key, JSON.stringify({ 'F-060': { watched: true, rating: 5 } }));
    localStorage.removeItem(meta); // meta yok = v1 kabul edilir
  }, KEY, META);
  await page.reload({ waitUntil: 'networkidle0' });
  await new Promise((r) => setTimeout(r, 300));
  esit('S3 veri bozulmadı', await page.evaluate((k) => JSON.parse(localStorage.getItem(k)), KEY), { 'F-060': { watched: true, rating: 5 } });
  esit('S3 yeniden migration ile meta=v2', await page.evaluate((k) => JSON.parse(localStorage.getItem(k))._schema, META), 2);

  // ============================================================
  console.log('\n== S4) restoreBackup sonrası state/meta tutarlılığı ==');
  const s4 = await page.evaluate((key, meta, bk) => {
    localStorage.clear();
    localStorage.setItem(meta, JSON.stringify({ _schema: 2, migratedFrom: 1 }));
    localStorage.setItem(key, JSON.stringify({ 'F-070': { rating: 9 } }));
    localStorage.setItem(bk, JSON.stringify({ 'F-071': { watched: true } })); // eski (v1) şema yedek
    const ok = restoreBackup();
    return { ok, state: JSON.parse(localStorage.getItem(key)), meta: JSON.parse(localStorage.getItem(meta)) };
  }, KEY, META, IMP_BACKUP);
  esit('S4 restoreBackup=true', s4.ok, true);
  esit('S4 state yedekten yüklendi', s4.state, { 'F-071': { watched: true } });
  esit('S4 meta yeniden v2 (tutarlı)', s4.meta._schema, 2);

  // ============================================================
  console.log('\n== S5) Migration tekrar çalışsa eski veriyi ezmez ==');
  const s5 = await page.evaluate((key, meta, mig) => {
    localStorage.clear();
    const veri = { 'F-080': { watched: true, rating: 7, ozel: 'korunmalı' } };
    localStorage.setItem(key, JSON.stringify(veri));
    const ilk = loadState();
    const stateSonrasi1 = localStorage.getItem(key);
    const meta1 = localStorage.getItem(meta);
    const yedek1 = localStorage.getItem(mig);
    const ikinci = loadState();   // tekrar çalıştır
    const stateSonrasi2 = localStorage.getItem(key);
    const meta2 = localStorage.getItem(meta);
    const yedek2 = localStorage.getItem(mig);
    return { ilk, ikinci, stateSonrasi1, stateSonrasi2, meta1, meta2, yedek1, yedek2 };
  }, KEY, META, MIG_BACKUP);
  esit('S5 ilk migration gerekli', s5.ilk.durum, 'migrate-edildi');
  esit('S5 ikinci migration gereksiz', s5.ikinci.durum, 'guncel');
  esit('S5 state 1. turdan sonra değişmedi', s5.stateSonrasi1, JSON.stringify({ 'F-080': { watched: true, rating: 7, ozel: 'korunmalı' } }));
  esit('S5 state 2. turdan sonra değişmedi', s5.stateSonrasi2, s5.stateSonrasi1);
  esit('S5 meta değişmedi', s5.meta2, s5.meta1);
  esit('S5 yedek değişmedi', s5.yedek2, s5.yedek1);

  // ============================================================
  console.log('\n== S6) Migration yedeği ile içe aktarma yedeği bağımsız ==');
  const s6 = await page.evaluate((key, meta, imp, mig) => {
    localStorage.clear();
    localStorage.setItem(key, JSON.stringify({ 'F-090': { rating: 3 } }));
    localStorage.setItem(imp, JSON.stringify({ 'IMPORT': true }));  // içe aktarma yedeği
    loadState();                                                     // migration
    return {
      imp: localStorage.getItem(imp),
      mig: JSON.parse(localStorage.getItem(mig)),
      impKey: localStorage.getItem(imp),
    };
  }, KEY, META, IMP_BACKUP, MIG_BACKUP);
  esit('S6 içe aktarma yedeği ezilmedi', s6.imp, JSON.stringify({ 'IMPORT': true }));
  esit('S6 migration yedeği doğru içerikte', s6.mig, { 'F-090': { rating: 3 } });
  esit('S6 iki anahtar farklı', s6.imp !== JSON.stringify(s6.mig), true);

  // ============================================================
  console.log('\n== S7) Kaynak kod kanıtı: migration KEY anahtarına yazmıyor ==');
  const kod = await page.evaluate(() => loadState.toString());
  esit('S7 loadState, META anahtarına yazar', kod.includes('SEMA_META_KEY'), true);
  esit('S7 loadState, KEY anahtarına yazmaz', /setItem\(\s*KEY/.test(kod), false);

  // ============================================================
  console.log('\n== S8) Çevrimdışı (file://) aynı senaryo ==');
  const page2 = await browser.newPage();
  page2.on('dialog', async (d) => { await d.accept(); });
  await page2.goto(FILE_URL, { waitUntil: 'load' });
  const s8 = await page2.evaluate((key, meta) => {
    localStorage.clear();
    localStorage.setItem(key, JSON.stringify({ 'F-100': { watched: false, rating: 4 } }));
    const orig = localStorage.setItem.bind(localStorage);
    localStorage.setItem = function (k, v) { if (k === meta) throw new Error('meta yazılamadı'); return orig(k, v); };
    const r = loadState();
    localStorage.setItem = orig;
    return { r, state: localStorage.getItem(key), meta: localStorage.getItem(meta) };
  }, KEY, META);
  esit('S8 file:// ok=false', s8.r.ok, false);
  esit('S8 file:// state değişmedi', s8.state, JSON.stringify({ 'F-100': { watched: false, rating: 4 } }));
  esit('S8 file:// meta yazılmadı', s8.meta, null);

  esit('Sayfa hatası yok', hatalar, []);
  await browser.close();
  console.log(`\nSONUÇ: ${gecen} geçti, ${kalan} kaldı`);
  process.exit(kalan ? 1 : 0);
})();
